﻿Imports MySql.Data.MySqlClient

Public Class UserControl_manageuser_list
    Private Sub UserControl_manageuser_list_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        displayDentist()
        cmbUserRole.SelectedIndex = 0
    End Sub

    Private Sub displayDentist()
        Dim table As New DataTable()
        conn.Open()
        Try
            comm = New MySqlCommand("prcSearchUser", conn)
            With comm
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@user_role", "Dentist")
                .Parameters.AddWithValue("@search_filter", cmbFilter.Text)
                .Parameters.AddWithValue("@search_value", txtSearchBox.Text)
                .ExecuteNonQuery()
            End With
            Dim da As New MySqlDataAdapter
            da.SelectCommand = comm
            Dim dt As New DataTable
            dt.Clear()

            da.Fill(dt)
            dgvUserlist.DataSource = dt
            Dim imgColumn = DirectCast(dgvUserlist.Columns(9), DataGridViewImageColumn)
            imgColumn.ImageLayout = DataGridViewImageCellLayout.Stretch
        Catch ex As Exception

        End Try
        conn.Close()
    End Sub

    Private Sub displayAdmin()
        Dim table As New DataTable()
        conn.Open()
        Try
            comm = New MySqlCommand("prcSearchUser", conn)
            With comm
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@user_role", "Admin")
                .Parameters.AddWithValue("@search_filter", cmbFilter.Text)
                .Parameters.AddWithValue("@search_value", txtSearchBox.Text)
                .ExecuteNonQuery()
            End With
            Dim da As New MySqlDataAdapter
            da.SelectCommand = comm
            Dim dt As New DataTable
            dt.Clear()

            da.Fill(dt)
            dgvUserlist.DataSource = dt

        Catch ex As Exception

        End Try
        conn.Close()
    End Sub

    Private Sub cmbUserRole_SelectedValueChanged(sender As Object, e As EventArgs) Handles cmbUserRole.SelectedValueChanged
        If cmbUserRole.Text = "Admin" Then
            displayAdmin()
        Else
            displayDentist()
        End If
    End Sub

    Private Sub txtSearchBox_TextChanged(sender As Object, e As EventArgs) Handles txtSearchBox.TextChanged
        If cmbUserRole.Text = "Admin" Then
            displayAdmin()
        Else
            displayDentist()
        End If
    End Sub

    Private Sub dgvUserlist_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvUserlist.CellClick
        Dim colName As String = dgvUserlist.Columns(e.ColumnIndex).Name
        Dim selectedRow As New DataGridViewRow
        Dim index As New Integer
        Try
            index = e.RowIndex
            selectedRow = dgvUserlist.Rows(index)
            If colName = "action_status" Then
                updateStatus(selectedRow.Cells(3).Value.ToString, selectedRow.Cells(8).Value.ToString)
                If cmbUserRole.Text = "Dentist" Then
                    displayDentist()
                Else
                    displayAdmin()
                End If
            ElseIf colName = "action_edit" Then
                With frm_admin_edituser
                    .urole = selectedRow.Cells(7).Value.ToString
                    .olduid = selectedRow.Cells(3).Value.ToString
                    .ShowDialog()
                End With
                If cmbUserRole.Text = "Dentist" Then
                    displayDentist()
                Else
                    displayAdmin()
                End If
            ElseIf colName = "action_delete" Then
                deleteUser(selectedRow.Cells(3).Value.ToString, selectedRow.Cells(7).Value.ToString)
                If cmbUserRole.Text = "Dentist" Then
                    displayDentist()
                Else
                    displayAdmin()
                End If
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub deleteUser(ByVal uid_delete As Integer, ByVal role As String)
        Dim dialogResult As DialogResult = MessageBox.Show("Do you want to delete this record?", "Manage User", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If dialogResult = DialogResult.Yes Then
            conn.Open()
            Try
                comm = New MySqlCommand("prcDeleteAccount", conn)
                With comm
                    .Parameters.Clear()
                    .CommandType = CommandType.StoredProcedure
                    .Parameters.AddWithValue("@userid", uid_delete)
                    .Parameters.AddWithValue("@urole", role)
                    .ExecuteNonQuery()
                End With
            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try
            conn.Close()
        End If
    End Sub

    Private Sub updateStatus(ByVal uid As Integer, ByVal status As String)
        Dim dialogResult As DialogResult
        Dim user_stats As String
        If status = "active" Then
            dialogResult = MessageBox.Show("Do you want to deactivate this account?", "Edit", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            user_stats = "inactive"
        Else
            dialogResult = MessageBox.Show("Do you want to activate this account?", "Edit", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            user_stats = "active"
        End If


        If dialogResult = DialogResult.Yes Then
            conn.Open()
            Try
                comm = New MySqlCommand("prcUpdateUserStatus", conn)
                With comm
                    .CommandType = CommandType.StoredProcedure
                    .Parameters.AddWithValue("@u_id", uid)
                    .Parameters.AddWithValue("@u_status", user_stats)
                    .ExecuteNonQuery()
                End With
            Catch ex As Exception
                conn.Close()
            End Try
            conn.Close()
        Else
        End If
        displayDentist()
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub
End Class
