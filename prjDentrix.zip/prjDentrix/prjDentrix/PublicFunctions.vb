﻿Imports System.IO
Imports MySql.Data.MySqlClient

Module PublicFunctions
    Public Sub deletePrintTbl()
        conn.Open()
        Try
            comm = New MySqlCommand("prcDeletePrintTable", conn)
            With comm
                .CommandType = CommandType.StoredProcedure
                .ExecuteNonQuery()
            End With

        Catch ex As Exception
            conn.Dispose()
        End Try
        conn.Close()
    End Sub

    Public Sub insertToLogs(dentist_id As Integer, source As String, action As String, name As String, message As String)
        conn.Open()
        Try
            comm = New MySqlCommand("prcAddLogs", conn)
            With comm
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@log_did", dentist_id)
                .Parameters.AddWithValue("@log_source", source)
                .Parameters.AddWithValue("@log_action", action)
                .Parameters.AddWithValue("@log_name", name)
                .Parameters.AddWithValue("@log_message", message)
                .ExecuteNonQuery()
            End With
        Catch ex As Exception
            conn.Dispose()
        End Try
        conn.Close()
    End Sub

    Public Sub export_file(dgv As DataGridView, moduleName As String)
        Dim sfd As New SaveFileDialog()
        sfd.FileName = "export_" & moduleName & "_" & Format(Date.Now, "ddMMyyy")
        sfd.Filter = "CSV File | *.csv"

        If sfd.ShowDialog() = DialogResult.OK Then
            Using sw As StreamWriter = File.CreateText(sfd.FileName)
                Dim dgvColumnNames As List(Of String) = dgv.Columns.Cast(Of DataGridViewColumn).ToList().Select(Function(c) c.Name).ToList()
                sw.WriteLine(String.Join(",", dgvColumnNames))

                For Each row As DataGridViewRow In dgv.Rows
                    Dim rowData As New List(Of String)
                    For Each column As DataGridViewColumn In dgv.Columns
                        rowData.Add(Convert.ToString(row.Cells(column.Name).Value))
                    Next
                    sw.WriteLine(String.Join(",", rowData))
                Next
                Process.Start(sfd.FileName)
            End Using
        End If
    End Sub

End Module
