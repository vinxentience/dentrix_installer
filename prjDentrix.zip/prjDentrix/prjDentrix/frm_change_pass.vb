﻿Imports MySql.Data.MySqlClient

Public Class frm_change_pass
    Private Sub txtPassword_TextChanged(sender As Object, e As EventArgs) Handles txtPassword.TextChanged
        If txtPassword.Text = "" Then
            Label2.Text = ""
            Label2.Visible = False
        ElseIf txtPassword.Text.Length < 8 Then
            Label2.Text = "Password must be 8 or more characters."
            Label2.Visible = True
        Else
            Label2.Text = ""
            Label2.Visible = False
        End If
    End Sub

    Private Sub txtConfirm_TextChanged(sender As Object, e As EventArgs) Handles txtConfirm.TextChanged
        If txtPassword.Text = "" Then
            Label3.Text = ""
            Label3.Visible = False
        ElseIf txtPassword.Text <> txtConfirm.Text Then
            Label3.Text = "Password doesn't match."
            Label3.Visible = True
        Else
            Label3.Text = ""
            Label3.Visible = False
        End If
    End Sub

    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        Dim dialogResult As DialogResult = MessageBox.Show("Do you want to change password?", "Password", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If dialogResult = DialogResult.Yes And ValidateInputs() And checkOldPass() Then
            conn.Open()
            Try
                comm = New MySqlCommand("prcUpdateAccount", conn)
                With comm
                    .CommandType = CommandType.StoredProcedure
                    .Parameters.AddWithValue("@old_uid", user_id)
                    .Parameters.AddWithValue("@new_uid", user_id)
                    .Parameters.AddWithValue("@upass", txtPassword.Text)
                    .Parameters.AddWithValue("@urole", u_role)
                    .ExecuteNonQuery()
                End With
            Catch ex As Exception
                conn.Close()
            End Try
            conn.Close()
            Me.Dispose()
        Else
        End If
    End Sub

    Private Function ValidateInputs() As Boolean
        If txtConfirm.Text = String.Empty Or txtPassword.Text = String.Empty Or txtOldPassword.Text = String.Empty Then
            MessageBox.Show("Please fill in the textbox.")
            Return False
        Else
            If txtPassword.Text <> txtConfirm.Text Then
                MessageBox.Show("Password does not match.")
                Return False
            ElseIf txtPassword.Text.Length < 8 Then
                MessageBox.Show("Password must at least 8 characters.")
                Return False
            End If
            Return True
        End If
    End Function

    Private Function checkOldPass() As Boolean
        Try
            conn.Open()
            comm = New MySqlCommand("prcCheckPassword", conn)
            With comm
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@uid", user_id)
                .Parameters.AddWithValue("@pass", txtOldPassword.Text)
                .ExecuteNonQuery()
            End With
            adapter = New MySqlDataAdapter(comm)
            Dim table As New DataTable()
            adapter.Fill(table)

            If table.Rows.Count = 0 Then
                MsgBox("ERROR", MsgBoxStyle.Critical)
            Else
                If table.Rows(0).Item(0).ToString() >= 1 Then
                    Label1.Visible = False
                    Label1.Text = ""
                    Return True
                Else
                    Label1.Visible = True
                    Label1.Text = "Old Password is incorrect"
                    Return False
                End If
            End If
            Return False
            conn.Close()
        Catch ex As Exception
            conn.Close()
            Return False
        Finally
            conn.Dispose()
        End Try
    End Function

End Class
