﻿Imports MySql.Data.MySqlClient

Public Class frm_browse_employee
    Public eid As String
    Public ename As String
    Private Sub frm_browse_employee_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        displayEmployee()
    End Sub

    Private Sub displayEmployee()
        Dim table As New DataTable()
        conn.Open()
        Try
            comm = New MySqlCommand("prcSearchEmployee", conn)
            With comm
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@did", user_id)
                .Parameters.AddWithValue("@ename", u_employee)
                .Parameters.AddWithValue("@search_filter", "All")
                .Parameters.AddWithValue("@search_input", "")
                .ExecuteNonQuery()
            End With
            Dim da As New MySqlDataAdapter
            da.SelectCommand = comm
            Dim dt As New DataTable
            dt.Clear()

            da.Fill(dt)
            dgvEmployee.DataSource = dt

        Catch ex As Exception

        End Try
        conn.Close()
    End Sub

    Private Sub dgvEmployee_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvEmployee.CellClick
        Dim colName As String = dgvEmployee.Columns(e.ColumnIndex).Name
        Dim selectedRow As DataGridViewRow
        Dim index As Integer
        Try
            index = e.RowIndex
            selectedRow = dgvEmployee.Rows(index)

            Dim dialogResult As DialogResult = MessageBox.Show("Do you want to select " + dgvEmployee.SelectedCells.Item(1).Value.ToString + "?", "Browse Patient", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            If dialogResult = DialogResult.Yes Then
                eid = selectedRow.Cells(0).Value.ToString
                ename = selectedRow.Cells(1).Value.ToString
                Me.Close()
            Else
                eid = ""
                ename = "[?]"
            End If

        Catch ex As Exception
        End Try
    End Sub

    Private Sub cmbFilter_SelectedValueChanged(sender As Object, e As EventArgs) Handles cmbFilter.SelectedValueChanged
        If cmbFilter.Text = "All" Then
            txtSearchBox.Enabled = False
        Else
            txtSearchBox.Enabled = True
        End If
    End Sub

    Private Sub txtSearchBox_TextChanged(sender As Object, e As EventArgs) Handles txtSearchBox.TextChanged
        Dim table As New DataTable()
        conn.Open()
        Try
            comm = New MySqlCommand("prcSearchEmployee", conn)
            With comm
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@did", user_id)
                .Parameters.AddWithValue("@ename", u_employee)
                .Parameters.AddWithValue("@search_filter", cmbFilter.Text)
                .Parameters.AddWithValue("@search_input", txtSearchBox.Text)
                .ExecuteNonQuery()
            End With
            Dim da As New MySqlDataAdapter
            da.SelectCommand = comm
            Dim dt As New DataTable
            dt.Clear()

            da.Fill(dt)
            dgvEmployee.DataSource = dt

        Catch ex As Exception

        End Try
        conn.Close()
    End Sub
End Class