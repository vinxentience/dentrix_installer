﻿Imports MySql.Data.MySqlClient

Public Class frmShowLogs
    Private Sub frmShowLogs_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        date_from.Value = DateTime.Today
        date_to.Value = DateTime.Today
        displayLogs()
    End Sub

    Private Sub displayLogs()
        Dim table As New DataTable()
        conn.Open()
        Try
            comm = New MySqlCommand("prcSearchLogs", conn)
            With comm
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@did", user_id)
                .Parameters.AddWithValue("@search_filter", "All")
                .Parameters.AddWithValue("@search_input", "")
                .Parameters.AddWithValue("@date_from", "" & " 00:00:00")
                .Parameters.AddWithValue("@date_to", "" & " 00:00:00")
                .ExecuteNonQuery()
            End With
            Dim da As New MySqlDataAdapter
            da.SelectCommand = comm
            Dim dt As New DataTable
            dt.Clear()

            da.Fill(dt)
            dgvLogs.DataSource = dt
            dgvLogs.DefaultCellStyle.WrapMode = DataGridViewTriState.True

        Catch ex As Exception

        End Try
        conn.Close()
    End Sub

    Private Sub filteredSearch()
        Dim table As New DataTable()
        conn.Open()
        Try
            comm = New MySqlCommand("prcSearchLogs", conn)
            With comm
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@did", user_id)
                .Parameters.AddWithValue("@search_filter", cmbFilter.Text)
                .Parameters.AddWithValue("@search_input", txtSearchBox.Text)
                .Parameters.AddWithValue("@date_from", date_from.Value.ToString("yyyy-MM-dd") & " 00:00:00")
                .Parameters.AddWithValue("@date_to", date_to.Value.ToString("yyyy-MM-dd") & " 23:59:00")
                .ExecuteNonQuery()
            End With
            Dim da As New MySqlDataAdapter
            da.SelectCommand = comm
            Dim dt As New DataTable
            dt.Clear()
            da.Fill(dt)
            dgvLogs.DataSource = dt

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        conn.Close()
    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        filteredSearch()
    End Sub

    Private Sub cmbFilter_SelectedValueChanged(sender As Object, e As EventArgs) Handles cmbFilter.SelectedValueChanged
        If cmbFilter.Text = "All" Then
            date_from.Enabled = False
            date_to.Enabled = False
            txtSearchBox.Enabled = False
            txtSearchBox.Clear()
            filteredSearch()
        ElseIf cmbFilter.Text = "By Date"
            date_from.Enabled = True
            date_to.Enabled = True
            date_from.Value = DateTime.Today
            date_to.Value = DateTime.Today
            txtSearchBox.Clear()
        Else
            date_from.Enabled = False
            date_to.Enabled = False
            txtSearchBox.Enabled = True
            txtSearchBox.Clear()
        End If
    End Sub

    Private Sub chkboxAutoSearch_CheckedChanged(sender As Object, e As EventArgs) Handles chkboxAutoSearch.CheckedChanged
        If chkboxAutoSearch.Checked = True Then
            btnSearch.Enabled = False
        Else
            btnSearch.Enabled = True
        End If
    End Sub

    Private Sub date_from_ValueChanged(sender As Object, e As EventArgs) Handles date_from.ValueChanged
        If chkboxAutoSearch.Checked = True Then
            filteredSearch()
        End If
    End Sub

    Private Sub date_to_ValueChanged(sender As Object, e As EventArgs) Handles date_to.ValueChanged
        If chkboxAutoSearch.Checked = True Then
            filteredSearch()
        End If
    End Sub

    Private Sub txtSearchBox_TextChanged(sender As Object, e As EventArgs) Handles txtSearchBox.TextChanged
        If chkboxAutoSearch.Checked = True Then
            filteredSearch()
        End If
    End Sub

End Class