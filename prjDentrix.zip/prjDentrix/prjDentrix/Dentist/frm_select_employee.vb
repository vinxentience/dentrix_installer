﻿Imports MySql.Data.MySqlClient

Public Class frm_select_employee
    Dim row As Integer
    Private Sub frm_select_employee_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            conn.Open()
            comm = New MySqlCommand("prcGetEmployee", conn)
            With comm
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@did", user_id)
                .ExecuteNonQuery()
            End With

            cmbEmployee.Items.Add(u_fname + " " + u_lname)
            cmbEmployee.SelectedIndex = 0

            row = 0
            adapter = New MySqlDataAdapter(comm)
            Dim table As New DataTable()
            adapter.Fill(table)
            While row < table.Rows.Count
                cmbEmployee.Items.Add(table.Rows(row)(0).ToString)
                row = row + 1
            End While

            conn.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            conn.Dispose()
        End Try
    End Sub



    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        u_employee = cmbEmployee.Text
        Me.Dispose()
        Me.Close()
    End Sub
End Class