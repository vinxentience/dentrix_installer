﻿Imports MySql.Data.MySqlClient

Public Class frm_edit_delete_employee
    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        With frm_browse_employee
            .ShowDialog()
            txtEID.Text = .eid
            txtFname.Text = .ename
        End With
    End Sub

    Private Sub IconButton1_Click(sender As Object, e As EventArgs) Handles IconButton1.Click
        Dim dialogResult As DialogResult = MessageBox.Show("Do you want to delete this record?", "Employee", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If dialogResult = DialogResult.Yes Then
            conn.Open()
            Try
                comm = New MySqlCommand("prcDeleteEmployee", conn)
                With comm
                    .CommandType = CommandType.StoredProcedure
                    .Parameters.AddWithValue("@did", user_id)
                    .Parameters.AddWithValue("@eid", txtEID.Text)
                    .ExecuteNonQuery()
                End With
            Catch ex As Exception
                conn.Close()
            End Try
            Me.Dispose()
            conn.Close()
        End If
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        Dim dialogResult As DialogResult = MessageBox.Show("Do you want to update this record?", "Employee", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If dialogResult = DialogResult.Yes Then
            conn.Open()
            Try
                comm = New MySqlCommand("prcUpdateEmployee", conn)
                With comm
                    .CommandType = CommandType.StoredProcedure
                    .Parameters.AddWithValue("@did", user_id)
                    .Parameters.AddWithValue("@eid", txtEID.Text)
                    .Parameters.AddWithValue("@ename", txtFname.Text)
                    .ExecuteNonQuery()
                End With
            Catch ex As Exception
                conn.Close()
            End Try
            Me.Dispose()
            conn.Close()
        End If
    End Sub

    Private Sub frm_edit_delete_employee_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub IconButton2_Click(sender As Object, e As EventArgs) Handles IconButton2.Click
        frm_insert_employee.ShowDialog()
    End Sub
End Class