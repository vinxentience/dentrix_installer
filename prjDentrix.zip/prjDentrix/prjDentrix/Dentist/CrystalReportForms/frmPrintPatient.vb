﻿Public Class frmPrintPatient
    Private Sub frmPrintPatient_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        Me.Dispose()
    End Sub
End Class