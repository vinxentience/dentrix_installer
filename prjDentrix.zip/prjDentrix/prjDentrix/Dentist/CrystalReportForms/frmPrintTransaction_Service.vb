﻿Public Class frmPrintTransaction_Service
    Private Sub frmPrintTransaction_Service_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        Me.Dispose()
    End Sub

End Class