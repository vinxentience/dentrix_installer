﻿Public Class frmPrintService
    Private Sub frmPrintService_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        Me.Dispose()
    End Sub
End Class