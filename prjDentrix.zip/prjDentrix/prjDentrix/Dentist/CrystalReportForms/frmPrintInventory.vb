﻿Public Class frmPrintInventory
    Private Sub frmPrintInventory_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        Me.Dispose()
    End Sub
End Class