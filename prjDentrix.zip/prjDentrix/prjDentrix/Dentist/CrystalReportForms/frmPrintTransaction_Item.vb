﻿Public Class frmPrintTransaction_Item
    Private Sub frmPrintTransaction_Item_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        Me.Dispose()
    End Sub
End Class