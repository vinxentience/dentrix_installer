﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class UserControl_dashboard
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Guna2GradientPanel1 = New Guna.UI2.WinForms.Guna2GradientPanel()
        Me.lblTotalPatient = New System.Windows.Forms.Label()
        Me.label2 = New System.Windows.Forms.Label()
        Me.IconPictureBox1 = New FontAwesome.Sharp.IconPictureBox()
        Me.Guna2GradientPanel2 = New Guna.UI2.WinForms.Guna2GradientPanel()
        Me.lblAppointmentToday = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.IconPictureBox2 = New FontAwesome.Sharp.IconPictureBox()
        Me.IconPictureBox3 = New FontAwesome.Sharp.IconPictureBox()
        Me.Guna2GradientPanel3 = New Guna.UI2.WinForms.Guna2GradientPanel()
        Me.lblTotalItems = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.MonthCalendar1 = New System.Windows.Forms.MonthCalendar()
        Me.Guna2GroupBox1 = New Guna.UI2.WinForms.Guna2GroupBox()
        Me.Guna2GradientPanel4 = New Guna.UI2.WinForms.Guna2GradientPanel()
        Me.lblTotalProfitService = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.IconPictureBox4 = New FontAwesome.Sharp.IconPictureBox()
        Me.Guna2GradientPanel5 = New Guna.UI2.WinForms.Guna2GradientPanel()
        Me.lblTotalProfitItem = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.IconPictureBox5 = New FontAwesome.Sharp.IconPictureBox()
        Me.Guna2GradientPanel6 = New Guna.UI2.WinForms.Guna2GradientPanel()
        Me.lblTotalUser = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.IconPictureBox6 = New FontAwesome.Sharp.IconPictureBox()
        Me.Guna2GradientPanel1.SuspendLayout()
        CType(Me.IconPictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Guna2GradientPanel2.SuspendLayout()
        CType(Me.IconPictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.IconPictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Guna2GradientPanel3.SuspendLayout()
        Me.Guna2GroupBox1.SuspendLayout()
        Me.Guna2GradientPanel4.SuspendLayout()
        CType(Me.IconPictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Guna2GradientPanel5.SuspendLayout()
        CType(Me.IconPictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Guna2GradientPanel6.SuspendLayout()
        CType(Me.IconPictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Guna2GradientPanel1
        '
        Me.Guna2GradientPanel1.BorderRadius = 10
        Me.Guna2GradientPanel1.Controls.Add(Me.lblTotalPatient)
        Me.Guna2GradientPanel1.Controls.Add(Me.label2)
        Me.Guna2GradientPanel1.Controls.Add(Me.IconPictureBox1)
        Me.Guna2GradientPanel1.FillColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.Guna2GradientPanel1.FillColor2 = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(88, Byte), Integer))
        Me.Guna2GradientPanel1.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal
        Me.Guna2GradientPanel1.Location = New System.Drawing.Point(5, 46)
        Me.Guna2GradientPanel1.Name = "Guna2GradientPanel1"
        Me.Guna2GradientPanel1.ShadowDecoration.Parent = Me.Guna2GradientPanel1
        Me.Guna2GradientPanel1.Size = New System.Drawing.Size(285, 126)
        Me.Guna2GradientPanel1.TabIndex = 0
        '
        'lblTotalPatient
        '
        Me.lblTotalPatient.AutoSize = True
        Me.lblTotalPatient.BackColor = System.Drawing.Color.Transparent
        Me.lblTotalPatient.Font = New System.Drawing.Font("Impact", 21.75!)
        Me.lblTotalPatient.ForeColor = System.Drawing.Color.White
        Me.lblTotalPatient.Location = New System.Drawing.Point(21, 45)
        Me.lblTotalPatient.Name = "lblTotalPatient"
        Me.lblTotalPatient.Size = New System.Drawing.Size(31, 36)
        Me.lblTotalPatient.TabIndex = 2
        Me.lblTotalPatient.Text = "0"
        '
        'label2
        '
        Me.label2.AutoSize = True
        Me.label2.BackColor = System.Drawing.Color.Transparent
        Me.label2.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label2.ForeColor = System.Drawing.Color.White
        Me.label2.Location = New System.Drawing.Point(26, 28)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(94, 17)
        Me.label2.TabIndex = 1
        Me.label2.Text = "Total Patients"
        '
        'IconPictureBox1
        '
        Me.IconPictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.IconPictureBox1.IconChar = FontAwesome.Sharp.IconChar.UserCircle
        Me.IconPictureBox1.IconColor = System.Drawing.Color.White
        Me.IconPictureBox1.IconFont = FontAwesome.Sharp.IconFont.[Auto]
        Me.IconPictureBox1.IconSize = 129
        Me.IconPictureBox1.Location = New System.Drawing.Point(182, 34)
        Me.IconPictureBox1.Name = "IconPictureBox1"
        Me.IconPictureBox1.Size = New System.Drawing.Size(140, 129)
        Me.IconPictureBox1.TabIndex = 1
        Me.IconPictureBox1.TabStop = False
        '
        'Guna2GradientPanel2
        '
        Me.Guna2GradientPanel2.BorderRadius = 10
        Me.Guna2GradientPanel2.Controls.Add(Me.lblAppointmentToday)
        Me.Guna2GradientPanel2.Controls.Add(Me.Label3)
        Me.Guna2GradientPanel2.Controls.Add(Me.IconPictureBox2)
        Me.Guna2GradientPanel2.FillColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(51, Byte), Integer), CType(CType(73, Byte), Integer))
        Me.Guna2GradientPanel2.FillColor2 = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(88, Byte), Integer))
        Me.Guna2GradientPanel2.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal
        Me.Guna2GradientPanel2.Location = New System.Drawing.Point(312, 195)
        Me.Guna2GradientPanel2.Name = "Guna2GradientPanel2"
        Me.Guna2GradientPanel2.ShadowDecoration.Parent = Me.Guna2GradientPanel2
        Me.Guna2GradientPanel2.Size = New System.Drawing.Size(285, 126)
        Me.Guna2GradientPanel2.TabIndex = 3
        '
        'lblAppointmentToday
        '
        Me.lblAppointmentToday.AutoSize = True
        Me.lblAppointmentToday.BackColor = System.Drawing.Color.Transparent
        Me.lblAppointmentToday.Font = New System.Drawing.Font("Impact", 21.75!)
        Me.lblAppointmentToday.ForeColor = System.Drawing.Color.White
        Me.lblAppointmentToday.Location = New System.Drawing.Point(21, 45)
        Me.lblAppointmentToday.Name = "lblAppointmentToday"
        Me.lblAppointmentToday.Size = New System.Drawing.Size(31, 36)
        Me.lblAppointmentToday.TabIndex = 2
        Me.lblAppointmentToday.Text = "0"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(26, 28)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(144, 17)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "Today's Appointment"
        '
        'IconPictureBox2
        '
        Me.IconPictureBox2.BackColor = System.Drawing.Color.Transparent
        Me.IconPictureBox2.IconChar = FontAwesome.Sharp.IconChar.CalendarCheck
        Me.IconPictureBox2.IconColor = System.Drawing.Color.White
        Me.IconPictureBox2.IconFont = FontAwesome.Sharp.IconFont.[Auto]
        Me.IconPictureBox2.IconSize = 116
        Me.IconPictureBox2.Location = New System.Drawing.Point(195, 34)
        Me.IconPictureBox2.Name = "IconPictureBox2"
        Me.IconPictureBox2.Size = New System.Drawing.Size(136, 116)
        Me.IconPictureBox2.TabIndex = 1
        Me.IconPictureBox2.TabStop = False
        '
        'IconPictureBox3
        '
        Me.IconPictureBox3.BackColor = System.Drawing.Color.Transparent
        Me.IconPictureBox3.IconChar = FontAwesome.Sharp.IconChar.BoxOpen
        Me.IconPictureBox3.IconColor = System.Drawing.Color.White
        Me.IconPictureBox3.IconFont = FontAwesome.Sharp.IconFont.[Auto]
        Me.IconPictureBox3.IconSize = 129
        Me.IconPictureBox3.Location = New System.Drawing.Point(182, 36)
        Me.IconPictureBox3.Name = "IconPictureBox3"
        Me.IconPictureBox3.Size = New System.Drawing.Size(140, 129)
        Me.IconPictureBox3.TabIndex = 1
        Me.IconPictureBox3.TabStop = False
        '
        'Guna2GradientPanel3
        '
        Me.Guna2GradientPanel3.BorderRadius = 10
        Me.Guna2GradientPanel3.Controls.Add(Me.lblTotalItems)
        Me.Guna2GradientPanel3.Controls.Add(Me.Label5)
        Me.Guna2GradientPanel3.Controls.Add(Me.IconPictureBox3)
        Me.Guna2GradientPanel3.FillColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.Guna2GradientPanel3.FillColor2 = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(88, Byte), Integer))
        Me.Guna2GradientPanel3.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal
        Me.Guna2GradientPanel3.Location = New System.Drawing.Point(312, 46)
        Me.Guna2GradientPanel3.Name = "Guna2GradientPanel3"
        Me.Guna2GradientPanel3.ShadowDecoration.Parent = Me.Guna2GradientPanel3
        Me.Guna2GradientPanel3.Size = New System.Drawing.Size(285, 126)
        Me.Guna2GradientPanel3.TabIndex = 4
        '
        'lblTotalItems
        '
        Me.lblTotalItems.AutoSize = True
        Me.lblTotalItems.BackColor = System.Drawing.Color.Transparent
        Me.lblTotalItems.Font = New System.Drawing.Font("Impact", 21.75!)
        Me.lblTotalItems.ForeColor = System.Drawing.Color.White
        Me.lblTotalItems.Location = New System.Drawing.Point(21, 45)
        Me.lblTotalItems.Name = "lblTotalItems"
        Me.lblTotalItems.Size = New System.Drawing.Size(31, 36)
        Me.lblTotalItems.TabIndex = 2
        Me.lblTotalItems.Text = "0"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(26, 28)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(77, 17)
        Me.Label5.TabIndex = 1
        Me.Label5.Text = "Total Items"
        '
        'MonthCalendar1
        '
        Me.MonthCalendar1.Location = New System.Drawing.Point(28, 51)
        Me.MonthCalendar1.Name = "MonthCalendar1"
        Me.MonthCalendar1.TabIndex = 5
        '
        'Guna2GroupBox1
        '
        Me.Guna2GroupBox1.Controls.Add(Me.MonthCalendar1)
        Me.Guna2GroupBox1.CustomBorderColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(88, Byte), Integer))
        Me.Guna2GroupBox1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2GroupBox1.ForeColor = System.Drawing.Color.White
        Me.Guna2GroupBox1.Location = New System.Drawing.Point(312, 383)
        Me.Guna2GroupBox1.Name = "Guna2GroupBox1"
        Me.Guna2GroupBox1.ShadowDecoration.Parent = Me.Guna2GroupBox1
        Me.Guna2GroupBox1.Size = New System.Drawing.Size(285, 222)
        Me.Guna2GroupBox1.TabIndex = 6
        Me.Guna2GroupBox1.Text = "Calendar"
        '
        'Guna2GradientPanel4
        '
        Me.Guna2GradientPanel4.BorderRadius = 10
        Me.Guna2GradientPanel4.Controls.Add(Me.lblTotalProfitService)
        Me.Guna2GradientPanel4.Controls.Add(Me.Label4)
        Me.Guna2GradientPanel4.Controls.Add(Me.IconPictureBox4)
        Me.Guna2GradientPanel4.FillColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(51, Byte), Integer), CType(CType(73, Byte), Integer))
        Me.Guna2GradientPanel4.FillColor2 = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(88, Byte), Integer))
        Me.Guna2GradientPanel4.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal
        Me.Guna2GradientPanel4.Location = New System.Drawing.Point(5, 195)
        Me.Guna2GradientPanel4.Name = "Guna2GradientPanel4"
        Me.Guna2GradientPanel4.ShadowDecoration.Parent = Me.Guna2GradientPanel4
        Me.Guna2GradientPanel4.Size = New System.Drawing.Size(285, 126)
        Me.Guna2GradientPanel4.TabIndex = 7
        '
        'lblTotalProfitService
        '
        Me.lblTotalProfitService.AutoSize = True
        Me.lblTotalProfitService.BackColor = System.Drawing.Color.Transparent
        Me.lblTotalProfitService.Font = New System.Drawing.Font("Impact", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotalProfitService.ForeColor = System.Drawing.Color.White
        Me.lblTotalProfitService.Location = New System.Drawing.Point(21, 45)
        Me.lblTotalProfitService.Name = "lblTotalProfitService"
        Me.lblTotalProfitService.Size = New System.Drawing.Size(31, 36)
        Me.lblTotalProfitService.TabIndex = 2
        Me.lblTotalProfitService.Text = "0"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(26, 28)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(149, 17)
        Me.Label4.TabIndex = 1
        Me.Label4.Text = "Today's Profit (Service)"
        '
        'IconPictureBox4
        '
        Me.IconPictureBox4.BackColor = System.Drawing.Color.Transparent
        Me.IconPictureBox4.IconChar = FontAwesome.Sharp.IconChar.MoneyBillAlt
        Me.IconPictureBox4.IconColor = System.Drawing.Color.White
        Me.IconPictureBox4.IconFont = FontAwesome.Sharp.IconFont.[Auto]
        Me.IconPictureBox4.IconSize = 129
        Me.IconPictureBox4.Location = New System.Drawing.Point(182, 34)
        Me.IconPictureBox4.Name = "IconPictureBox4"
        Me.IconPictureBox4.Size = New System.Drawing.Size(140, 129)
        Me.IconPictureBox4.TabIndex = 1
        Me.IconPictureBox4.TabStop = False
        '
        'Guna2GradientPanel5
        '
        Me.Guna2GradientPanel5.BorderRadius = 10
        Me.Guna2GradientPanel5.Controls.Add(Me.lblTotalProfitItem)
        Me.Guna2GradientPanel5.Controls.Add(Me.Label7)
        Me.Guna2GradientPanel5.Controls.Add(Me.IconPictureBox5)
        Me.Guna2GradientPanel5.FillColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(51, Byte), Integer), CType(CType(73, Byte), Integer))
        Me.Guna2GradientPanel5.FillColor2 = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(88, Byte), Integer))
        Me.Guna2GradientPanel5.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal
        Me.Guna2GradientPanel5.Location = New System.Drawing.Point(618, 195)
        Me.Guna2GradientPanel5.Name = "Guna2GradientPanel5"
        Me.Guna2GradientPanel5.ShadowDecoration.Parent = Me.Guna2GradientPanel5
        Me.Guna2GradientPanel5.Size = New System.Drawing.Size(285, 126)
        Me.Guna2GradientPanel5.TabIndex = 8
        '
        'lblTotalProfitItem
        '
        Me.lblTotalProfitItem.AutoSize = True
        Me.lblTotalProfitItem.BackColor = System.Drawing.Color.Transparent
        Me.lblTotalProfitItem.Font = New System.Drawing.Font("Impact", 21.75!)
        Me.lblTotalProfitItem.ForeColor = System.Drawing.Color.White
        Me.lblTotalProfitItem.Location = New System.Drawing.Point(21, 45)
        Me.lblTotalProfitItem.Name = "lblTotalProfitItem"
        Me.lblTotalProfitItem.Size = New System.Drawing.Size(31, 36)
        Me.lblTotalProfitItem.TabIndex = 2
        Me.lblTotalProfitItem.Text = "0"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.White
        Me.Label7.Location = New System.Drawing.Point(26, 28)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(133, 17)
        Me.Label7.TabIndex = 1
        Me.Label7.Text = "Today's Profit (Item)"
        '
        'IconPictureBox5
        '
        Me.IconPictureBox5.BackColor = System.Drawing.Color.Transparent
        Me.IconPictureBox5.IconChar = FontAwesome.Sharp.IconChar.MoneyBillAlt
        Me.IconPictureBox5.IconColor = System.Drawing.Color.White
        Me.IconPictureBox5.IconFont = FontAwesome.Sharp.IconFont.[Auto]
        Me.IconPictureBox5.IconSize = 129
        Me.IconPictureBox5.Location = New System.Drawing.Point(174, 34)
        Me.IconPictureBox5.Name = "IconPictureBox5"
        Me.IconPictureBox5.Size = New System.Drawing.Size(140, 129)
        Me.IconPictureBox5.TabIndex = 1
        Me.IconPictureBox5.TabStop = False
        '
        'Guna2GradientPanel6
        '
        Me.Guna2GradientPanel6.BorderRadius = 10
        Me.Guna2GradientPanel6.Controls.Add(Me.lblTotalUser)
        Me.Guna2GradientPanel6.Controls.Add(Me.Label9)
        Me.Guna2GradientPanel6.Controls.Add(Me.IconPictureBox6)
        Me.Guna2GradientPanel6.FillColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(176, Byte), Integer))
        Me.Guna2GradientPanel6.FillColor2 = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(88, Byte), Integer))
        Me.Guna2GradientPanel6.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal
        Me.Guna2GradientPanel6.Location = New System.Drawing.Point(618, 46)
        Me.Guna2GradientPanel6.Name = "Guna2GradientPanel6"
        Me.Guna2GradientPanel6.ShadowDecoration.Parent = Me.Guna2GradientPanel6
        Me.Guna2GradientPanel6.Size = New System.Drawing.Size(285, 126)
        Me.Guna2GradientPanel6.TabIndex = 4
        '
        'lblTotalUser
        '
        Me.lblTotalUser.AutoSize = True
        Me.lblTotalUser.BackColor = System.Drawing.Color.Transparent
        Me.lblTotalUser.Font = New System.Drawing.Font("Impact", 21.75!)
        Me.lblTotalUser.ForeColor = System.Drawing.Color.White
        Me.lblTotalUser.Location = New System.Drawing.Point(21, 45)
        Me.lblTotalUser.Name = "lblTotalUser"
        Me.lblTotalUser.Size = New System.Drawing.Size(31, 36)
        Me.lblTotalUser.TabIndex = 2
        Me.lblTotalUser.Text = "0"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.White
        Me.Label9.Location = New System.Drawing.Point(26, 28)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(73, 17)
        Me.Label9.TabIndex = 1
        Me.Label9.Text = "Total Users"
        '
        'IconPictureBox6
        '
        Me.IconPictureBox6.BackColor = System.Drawing.Color.Transparent
        Me.IconPictureBox6.IconChar = FontAwesome.Sharp.IconChar.UserFriends
        Me.IconPictureBox6.IconColor = System.Drawing.Color.White
        Me.IconPictureBox6.IconFont = FontAwesome.Sharp.IconFont.[Auto]
        Me.IconPictureBox6.IconSize = 126
        Me.IconPictureBox6.Location = New System.Drawing.Point(180, 39)
        Me.IconPictureBox6.Name = "IconPictureBox6"
        Me.IconPictureBox6.Size = New System.Drawing.Size(153, 126)
        Me.IconPictureBox6.TabIndex = 1
        Me.IconPictureBox6.TabStop = False
        '
        'UserControl_dashboard
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.Controls.Add(Me.Guna2GradientPanel6)
        Me.Controls.Add(Me.Guna2GradientPanel5)
        Me.Controls.Add(Me.Guna2GradientPanel4)
        Me.Controls.Add(Me.Guna2GroupBox1)
        Me.Controls.Add(Me.Guna2GradientPanel3)
        Me.Controls.Add(Me.Guna2GradientPanel2)
        Me.Controls.Add(Me.Guna2GradientPanel1)
        Me.Name = "UserControl_dashboard"
        Me.Size = New System.Drawing.Size(909, 625)
        Me.Guna2GradientPanel1.ResumeLayout(False)
        Me.Guna2GradientPanel1.PerformLayout()
        CType(Me.IconPictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Guna2GradientPanel2.ResumeLayout(False)
        Me.Guna2GradientPanel2.PerformLayout()
        CType(Me.IconPictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.IconPictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Guna2GradientPanel3.ResumeLayout(False)
        Me.Guna2GradientPanel3.PerformLayout()
        Me.Guna2GroupBox1.ResumeLayout(False)
        Me.Guna2GradientPanel4.ResumeLayout(False)
        Me.Guna2GradientPanel4.PerformLayout()
        CType(Me.IconPictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Guna2GradientPanel5.ResumeLayout(False)
        Me.Guna2GradientPanel5.PerformLayout()
        CType(Me.IconPictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Guna2GradientPanel6.ResumeLayout(False)
        Me.Guna2GradientPanel6.PerformLayout()
        CType(Me.IconPictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Guna2GradientPanel1 As Guna.UI2.WinForms.Guna2GradientPanel
    Friend WithEvents lblTotalPatient As Label
    Friend WithEvents label2 As Label
    Friend WithEvents IconPictureBox1 As FontAwesome.Sharp.IconPictureBox
    Friend WithEvents Guna2GradientPanel2 As Guna.UI2.WinForms.Guna2GradientPanel
    Friend WithEvents lblAppointmentToday As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents IconPictureBox2 As FontAwesome.Sharp.IconPictureBox
    Friend WithEvents IconPictureBox3 As FontAwesome.Sharp.IconPictureBox
    Friend WithEvents Guna2GradientPanel3 As Guna.UI2.WinForms.Guna2GradientPanel
    Friend WithEvents lblTotalItems As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents MonthCalendar1 As MonthCalendar
    Friend WithEvents Guna2GroupBox1 As Guna.UI2.WinForms.Guna2GroupBox
    Friend WithEvents Guna2GradientPanel4 As Guna.UI2.WinForms.Guna2GradientPanel
    Friend WithEvents lblTotalProfitService As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents IconPictureBox4 As FontAwesome.Sharp.IconPictureBox
    Friend WithEvents Guna2GradientPanel5 As Guna.UI2.WinForms.Guna2GradientPanel
    Friend WithEvents lblTotalProfitItem As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents IconPictureBox5 As FontAwesome.Sharp.IconPictureBox
    Friend WithEvents Guna2GradientPanel6 As Guna.UI2.WinForms.Guna2GradientPanel
    Friend WithEvents lblTotalUser As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents IconPictureBox6 As FontAwesome.Sharp.IconPictureBox
End Class
