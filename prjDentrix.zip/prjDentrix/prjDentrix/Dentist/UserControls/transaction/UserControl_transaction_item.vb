﻿Imports MySql.Data.MySqlClient

Public Class UserControl_transaction_item
    Dim item_cost As Double
    Dim total_cost As Double
    Dim original_stock As Integer
    Private Sub Guna2Button2_Click(sender As Object, e As EventArgs) Handles btnBrowsePatient.Click
        With frm_browse_patient
            .ShowDialog()
            txtPatientID.Text = .pid
            lblPatientName.Text = .pname
        End With
    End Sub

    Private Sub Guna2Button1_Click(sender As Object, e As EventArgs) Handles btnBrowseItem.Click
        Try
            With frm_browse_item
                .ShowDialog()
                txtItemID.Text = .iid
                lblItemName.Text = .iname
                lblItemCost.Text = .icost
                nmrc_qty.Maximum = .iqty
            End With
            item_cost = lblItemCost.Text
        Catch ex As Exception

        End Try

    End Sub

    Private Sub txtItemID_TextChanged(sender As Object, e As EventArgs) Handles txtItemID.TextChanged
        If txtItemID.Text = "" Then
            txtAdditionalCharge.Enabled = False
            nmrc_qty.Enabled = False
        Else
            txtAdditionalCharge.Enabled = True
            nmrc_qty.Enabled = True
            total_cost = 0
            lblItemCost.Text = item_cost
            txtAdditionalCharge.Text = "0"
            nmrc_qty.Value = 1
        End If

    End Sub

    Private Sub UserControl_transaction_item_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        getMaxCol()
        displayItemTransaction()
        updatePrintTable(dgvItemCart)
        cancelAllTransaction()
        displayItemTransaction()
    End Sub

    Private Sub getMaxCol()
        conn.Open()
        Try
            comm = New MySqlCommand("prcGetMaxColumnItemTransaction", conn)
            With comm
                .CommandType = CommandType.StoredProcedure
                .ExecuteNonQuery()
            End With

            adapter = New MySqlDataAdapter(comm)
            Dim table As New DataTable()
            adapter.Fill(table)

            txtTransactionNo.Text = CInt(table.Rows(0).Item(0).ToString())

        Catch ex As Exception
            conn.Close()
        End Try
        conn.Close()
    End Sub

    Private Sub nmrc_qty_ValueChanged(sender As Object, e As EventArgs) Handles nmrc_qty.ValueChanged
        Try
            total_cost = (item_cost * nmrc_qty.Value) + CDbl(txtAdditionalCharge.Text)
        Catch ex As Exception

        End Try
        lblItemCost.Text = total_cost
    End Sub

    Private Sub txtAdditionalCharge_TextChanged(sender As Object, e As EventArgs) Handles txtAdditionalCharge.TextChanged
        If IsNumeric(txtAdditionalCharge.Text) = False And txtAdditionalCharge.Text <> "" Then
            MsgBox("Please enter numeric value.")
            txtAdditionalCharge.Clear()
        End If

        Try
            If txtAdditionalCharge.Text = "" Then
                total_cost = (item_cost * nmrc_qty.Value) + 0
            Else
                total_cost = (item_cost * nmrc_qty.Value) + CDbl(txtAdditionalCharge.Text)
            End If
        Catch ex As Exception

        End Try
        lblItemCost.Text = total_cost
    End Sub

    Private Sub displayItemTransaction()
        conn.Open()
        Try
            comm = New MySqlCommand("prcSelectPaymentItem", conn)
            With comm
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@tid", txtTransactionNo.Text)
                .ExecuteNonQuery()
            End With
            Dim da As New MySqlDataAdapter
            da.SelectCommand = comm
            Dim dt As New DataTable
            dt.Clear()
            da.Fill(dt)
            dgvItemCart.DataSource = dt
            If dt.Rows.Count > 0 Then
                btnBrowsePatient.Enabled = False
                btnConfirmTransaction.Visible = True
                btnDeleteTransaction.Visible = True
            Else
                btnBrowsePatient.Enabled = True
                btnConfirmTransaction.Visible = False
                btnDeleteTransaction.Visible = False
            End If
        Catch ex As Exception

        End Try
        conn.Close()
    End Sub

    Private Sub displaySubtotal()
        Try
            conn.Open()
            comm = New MySqlCommand("prcCalculateSubTotalItems", conn)
            With comm
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@tid", txtTransactionNo.Text)
                .ExecuteNonQuery()
            End With
            adapter = New MySqlDataAdapter(comm)
            Dim table As New DataTable()
            adapter.Fill(table)

            If table.Rows.Count < 1 Then
                txtSubtotal.Text = ""
            Else
                txtSubtotal.Text = Format(CDbl(table.Rows(0).Item(0).ToString()), "₱###,###,###.##")
            End If

            conn.Close()
        Catch ex As Exception
            txtSubtotal.Text = ""
            conn.Close()
        Finally
            conn.Dispose()
        End Try
    End Sub

    Private Sub InsertItemTransaction()
        Try
            comm = New MySqlCommand("prcInsertPaymentItem", conn)
            With comm
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@tid", txtTransactionNo.Text)
                .Parameters.AddWithValue("@iid", txtItemID.Text)
                .Parameters.AddWithValue("@iname", lblItemName.Text)
                .Parameters.AddWithValue("@acharge", txtAdditionalCharge.Text)
                .Parameters.AddWithValue("@icost", lblItemCost.Text)
                .Parameters.AddWithValue("@iqty", nmrc_qty.Value)
                .Parameters.AddWithValue("@pdate", Format(Date.Now, "yyyy-MM-dd"))
                .ExecuteNonQuery()
            End With
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub ConfirmItemTransaction()
        conn.Open()
        Try
            comm = New MySqlCommand("prcInsertTransactionItemRelationship", conn)
            With comm
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@did", txtTransactionNo.Text)
                .Parameters.AddWithValue("@pid", txtPatientID.Text)
                .Parameters.AddWithValue("@tid", lblItemName.Text)
                .Parameters.AddWithValue("@stotal", total_cost)
                .Parameters.AddWithValue("@amt", nmrc_qty.Value)
                .ExecuteNonQuery()
            End With
        Catch ex As Exception

        End Try
        conn.Close()
    End Sub

    Private Sub cancelAllTransaction()
        conn.Open()
        Try
            comm = New MySqlCommand("prcDeleteTransactionItem", conn)
            With comm
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@tid", txtTransactionNo.Text)
                .ExecuteNonQuery()
            End With
        Catch ex As Exception

        End Try
        conn.Close()
    End Sub

    Private Sub updatePrintTable(ByRef printTable As DataGridView)
        Dim row As Integer

        Try
            row = 0
            While row < printTable.RowCount
                With printTable
                    rollbackQuantity(.Rows(row).Cells(2).Value.ToString,
                                    .Rows(row).Cells(4).Value.ToString)
                End With
                row = row + 1
            End While
        Catch ex As Exception
            MsgBox("" + ex.Message)
        End Try
    End Sub

    Private Sub rollbackQuantity(ByRef iid As Integer, ByRef iqty As Integer)
        conn.Open()
        Try
            comm = New MySqlCommand("prcRollbackQty", conn)
            With comm
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@iid", iid)
                .Parameters.AddWithValue("@iqty", iqty)
                .Parameters.AddWithValue("@tiid", txtTransactionNo.Text)
                .ExecuteNonQuery()
            End With
        Catch ex As Exception
            MsgBox("" + ex.Message)
        End Try
        conn.Close()
    End Sub

    Private Sub Guna2Button3_Click(sender As Object, e As EventArgs) Handles Guna2Button3.Click
        If ValidateInputs() Then
            checkIfExist()
            displaySubtotal()
            ClearInputs()
        End If
        displayItemTransaction()
    End Sub

    Private Sub checkIfExist()
        conn.Open()
        Try
            comm = New MySqlCommand("prcCheckIfItemExist", conn)
            With comm
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@tid", txtTransactionNo.Text)
                .Parameters.AddWithValue("@iid", txtItemID.Text)
                .ExecuteNonQuery()
            End With
            Dim da As New MySqlDataAdapter
            da.SelectCommand = comm
            Dim dt As New DataTable
            dt.Clear()
            da.Fill(dt)
            If dt.Rows(0).Item(0).ToString() >= 1 Then
                mergeDuplicateItems(dt.Rows(0).Item(1).ToString(), dt.Rows(0).Item(2).ToString())
                updateInventoryStock()
            Else
                InsertItemTransaction()
                updateInventoryStock()
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        conn.Close()
    End Sub

    Private Sub mergeDuplicateItems(ByVal total_qty_merge As Integer, ByVal total_cost_merge As Double)
        Try
            comm = New MySqlCommand("prcUpdatePaymentQuantityItem", conn)
            With comm
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@tid", txtTransactionNo.Text)
                .Parameters.AddWithValue("@iid", txtItemID.Text)
                .Parameters.AddWithValue("@iqty", nmrc_qty.Value + total_qty_merge)
                .Parameters.AddWithValue("@icost", CDbl(lblItemCost.Text) + total_cost_merge)
                .ExecuteNonQuery()
            End With
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub updateInventoryStock()
        Dim remaining_stock As Integer
        Dim updated_stock As Integer
        Try
            comm = New MySqlCommand("prcGetItemStock", conn)
            With comm
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@iid", txtItemID.Text)
                .ExecuteNonQuery()
            End With
            Dim da As New MySqlDataAdapter
            da.SelectCommand = comm
            Dim dt As New DataTable
            dt.Clear()
            da.Fill(dt)
            remaining_stock = dt.Rows(0).Item(0).ToString()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        updated_stock = remaining_stock - nmrc_qty.Value
        Try
            comm = New MySqlCommand("prcUpdateItemStock", conn)
            With comm
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@iid", txtItemID.Text)
                .Parameters.AddWithValue("@iqty", updated_stock)
                .ExecuteNonQuery()
            End With
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Function ValidateInputs() As Boolean
        If txtPatientID.Text = String.Empty Or txtItemID.Text = String.Empty Or txtTransactionNo.Text = "[?]" Then
            MessageBox.Show("Please make sure to fill in the textboxes.")
            Return False
        Else
            If IsNumeric(txtAdditionalCharge.Text) = False Then
                MessageBox.Show("Additional Charge Must be numeric.")
                Return False
            End If

            If nmrc_qty.Value = 0 Then
                MessageBox.Show("Sorry but this item is out of stock.")
                Return False
            End If

            Return True
        End If
    End Function

    Private Sub ClearInputs()
        Try
            txtItemID.Text = String.Empty
            nmrc_qty.Value = 1.0
            nmrc_qty.Enabled = False
            lblItemCost.Text = "[?]"
            lblItemName.Text = "[?]"
            txtAdditionalCharge.Text = "0"
            item_cost = 0
            total_cost = 0
        Catch ex As Exception

        End Try

    End Sub

    Private Sub Guna2Button4_Click(sender As Object, e As EventArgs) Handles Guna2Button4.Click
        ClearInputs()
        lblItemName.Text = "[?]"
        lblItemCost.Text = "[?]"
    End Sub

    Private Sub Guna2Button6_Click(sender As Object, e As EventArgs) Handles btnDeleteTransaction.Click
        Dim dialogResult As DialogResult = MessageBox.Show("Do you want to cancel this transaction?", "Transaction", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If dialogResult = DialogResult.Yes Then
            updatePrintTable(dgvItemCart)
            cancelAllTransaction()
            displayItemTransaction()
            txtSubtotal.Text = ""
        End If

    End Sub

    Private Sub Guna2Button5_Click(sender As Object, e As EventArgs) Handles btnConfirmTransaction.Click
        Try
            With frm_confirm_payment
                .subtotal = CDbl(txtSubtotal.Text)
                .patient_payer = txtPatientID.Text
                .transaction_no = txtTransactionNo.Text
                .transaction_type = "Item"
                .ShowDialog()
                getMaxCol()
                ClearInputs()
                displayItemTransaction()

                If .isSubmitted Then
                    txtPatientID.Text = ""
                    lblPatientName.Text = "[?]"
                    txtSubtotal.Text = ""
                Else
                End If
            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Sub dgvItemCart_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvItemCart.CellClick
        Dim colName As String = dgvItemCart.Columns(e.ColumnIndex).Name
        Dim selectedRow As New DataGridViewRow
        Dim index As New Integer
        Try
            index = e.RowIndex
            selectedRow = dgvItemCart.Rows(index)
            If colName = "action_delete" Then

                rollbackQuantity(selectedRow.Cells(2).Value.ToString, selectedRow.Cells(4).Value.ToString)
                delete_item(selectedRow.Cells(1).Value.ToString, selectedRow.Cells(2).Value.ToString)
                displaySubtotal()
                displayItemTransaction()
            End If
        Catch ex As Exception
        End Try
    End Sub
    Private Sub delete_item(ByVal tid As Integer, ByVal iid As Integer)
        Dim dialogResult As DialogResult = MessageBox.Show("Do you want to delete this record?", "Item", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If dialogResult = DialogResult.Yes Then
            conn.Open()
            Try
                comm = New MySqlCommand("prcDeleteItemFromCart", conn)
                With comm
                    .CommandType = CommandType.StoredProcedure
                    .Parameters.AddWithValue("@tid", tid)
                    .Parameters.AddWithValue("@iid", iid)
                    .ExecuteNonQuery()
                End With
            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try
            conn.Close()
        End If
    End Sub

    'Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
    '    ClearInputs()
    'End Sub
End Class
