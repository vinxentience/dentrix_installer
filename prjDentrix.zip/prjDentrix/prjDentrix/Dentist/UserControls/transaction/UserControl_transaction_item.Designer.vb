﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class UserControl_transaction_item
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(UserControl_transaction_item))
        Me.Guna2GroupBox1 = New Guna.UI2.WinForms.Guna2GroupBox()
        Me.txtTransactionNo = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Guna2Button4 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button3 = New Guna.UI2.WinForms.Guna2Button()
        Me.txtAdditionalCharge = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.nmrc_qty = New Guna.UI2.WinForms.Guna2NumericUpDown()
        Me.lblItemCost = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblItemName = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnBrowsePatient = New Guna.UI2.WinForms.Guna2Button()
        Me.btnBrowseItem = New Guna.UI2.WinForms.Guna2Button()
        Me.txtItemID = New Guna.UI2.WinForms.Guna2TextBox()
        Me.lblPatientName = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtPatientID = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.dgvItemCart = New Guna.UI2.WinForms.Guna2DataGridView()
        Me.action_delete = New System.Windows.Forms.DataGridViewImageColumn()
        Me.btnConfirmTransaction = New Guna.UI2.WinForms.Guna2Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtSubtotal = New Guna.UI2.WinForms.Guna2TextBox()
        Me.btnDeleteTransaction = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2GroupBox1.SuspendLayout()
        CType(Me.nmrc_qty, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        CType(Me.dgvItemCart, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Guna2GroupBox1
        '
        Me.Guna2GroupBox1.Controls.Add(Me.txtTransactionNo)
        Me.Guna2GroupBox1.Controls.Add(Me.Label4)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2Button4)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2Button3)
        Me.Guna2GroupBox1.Controls.Add(Me.txtAdditionalCharge)
        Me.Guna2GroupBox1.Controls.Add(Me.Label9)
        Me.Guna2GroupBox1.Controls.Add(Me.Label8)
        Me.Guna2GroupBox1.Controls.Add(Me.nmrc_qty)
        Me.Guna2GroupBox1.Controls.Add(Me.lblItemCost)
        Me.Guna2GroupBox1.Controls.Add(Me.Label1)
        Me.Guna2GroupBox1.Controls.Add(Me.lblItemName)
        Me.Guna2GroupBox1.Controls.Add(Me.Label2)
        Me.Guna2GroupBox1.Controls.Add(Me.btnBrowsePatient)
        Me.Guna2GroupBox1.Controls.Add(Me.btnBrowseItem)
        Me.Guna2GroupBox1.Controls.Add(Me.txtItemID)
        Me.Guna2GroupBox1.Controls.Add(Me.lblPatientName)
        Me.Guna2GroupBox1.Controls.Add(Me.Label3)
        Me.Guna2GroupBox1.Controls.Add(Me.txtPatientID)
        Me.Guna2GroupBox1.CustomBorderColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(88, Byte), Integer))
        Me.Guna2GroupBox1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2GroupBox1.ForeColor = System.Drawing.Color.White
        Me.Guna2GroupBox1.Location = New System.Drawing.Point(12, 5)
        Me.Guna2GroupBox1.Name = "Guna2GroupBox1"
        Me.Guna2GroupBox1.ShadowDecoration.Parent = Me.Guna2GroupBox1
        Me.Guna2GroupBox1.Size = New System.Drawing.Size(885, 206)
        Me.Guna2GroupBox1.TabIndex = 32
        Me.Guna2GroupBox1.Text = "Add Transaction (Item)"
        '
        'txtTransactionNo
        '
        Me.txtTransactionNo.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(88, Byte), Integer))
        Me.txtTransactionNo.BorderColor = System.Drawing.Color.White
        Me.txtTransactionNo.BorderRadius = 5
        Me.txtTransactionNo.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtTransactionNo.DefaultText = ""
        Me.txtTransactionNo.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.txtTransactionNo.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.txtTransactionNo.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtTransactionNo.DisabledState.Parent = Me.txtTransactionNo
        Me.txtTransactionNo.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtTransactionNo.Enabled = False
        Me.txtTransactionNo.FillColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(88, Byte), Integer))
        Me.txtTransactionNo.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtTransactionNo.FocusedState.Parent = Me.txtTransactionNo
        Me.txtTransactionNo.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTransactionNo.ForeColor = System.Drawing.Color.White
        Me.txtTransactionNo.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtTransactionNo.HoverState.Parent = Me.txtTransactionNo
        Me.txtTransactionNo.Location = New System.Drawing.Point(722, 7)
        Me.txtTransactionNo.Margin = New System.Windows.Forms.Padding(5, 5, 5, 5)
        Me.txtTransactionNo.Name = "txtTransactionNo"
        Me.txtTransactionNo.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtTransactionNo.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(88, Byte), Integer))
        Me.txtTransactionNo.PlaceholderText = ""
        Me.txtTransactionNo.SelectedText = ""
        Me.txtTransactionNo.ShadowDecoration.Parent = Me.txtTransactionNo
        Me.txtTransactionNo.Size = New System.Drawing.Size(154, 26)
        Me.txtTransactionNo.TabIndex = 43
        Me.txtTransactionNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(88, Byte), Integer))
        Me.Label4.Location = New System.Drawing.Point(629, 11)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(89, 15)
        Me.Label4.TabIndex = 41
        Me.Label4.Text = "Transaction No."
        '
        'Guna2Button4
        '
        Me.Guna2Button4.BorderRadius = 20
        Me.Guna2Button4.CheckedState.Parent = Me.Guna2Button4
        Me.Guna2Button4.CustomImages.Parent = Me.Guna2Button4
        Me.Guna2Button4.FillColor = System.Drawing.Color.SeaGreen
        Me.Guna2Button4.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2Button4.ForeColor = System.Drawing.Color.White
        Me.Guna2Button4.HoverState.Parent = Me.Guna2Button4
        Me.Guna2Button4.Location = New System.Drawing.Point(194, 156)
        Me.Guna2Button4.Name = "Guna2Button4"
        Me.Guna2Button4.ShadowDecoration.Parent = Me.Guna2Button4
        Me.Guna2Button4.Size = New System.Drawing.Size(160, 38)
        Me.Guna2Button4.TabIndex = 40
        Me.Guna2Button4.Text = "Clear"
        '
        'Guna2Button3
        '
        Me.Guna2Button3.BorderRadius = 20
        Me.Guna2Button3.CheckedState.Parent = Me.Guna2Button3
        Me.Guna2Button3.CustomImages.Parent = Me.Guna2Button3
        Me.Guna2Button3.FillColor = System.Drawing.Color.SeaGreen
        Me.Guna2Button3.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2Button3.ForeColor = System.Drawing.Color.White
        Me.Guna2Button3.HoverState.Parent = Me.Guna2Button3
        Me.Guna2Button3.Location = New System.Drawing.Point(16, 156)
        Me.Guna2Button3.Name = "Guna2Button3"
        Me.Guna2Button3.ShadowDecoration.Parent = Me.Guna2Button3
        Me.Guna2Button3.Size = New System.Drawing.Size(160, 38)
        Me.Guna2Button3.TabIndex = 39
        Me.Guna2Button3.Text = "Add Item"
        '
        'txtAdditionalCharge
        '
        Me.txtAdditionalCharge.BorderColor = System.Drawing.SystemColors.ControlDark
        Me.txtAdditionalCharge.BorderRadius = 10
        Me.txtAdditionalCharge.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtAdditionalCharge.DefaultText = "0"
        Me.txtAdditionalCharge.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.txtAdditionalCharge.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.txtAdditionalCharge.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtAdditionalCharge.DisabledState.Parent = Me.txtAdditionalCharge
        Me.txtAdditionalCharge.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtAdditionalCharge.Enabled = False
        Me.txtAdditionalCharge.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtAdditionalCharge.FocusedState.Parent = Me.txtAdditionalCharge
        Me.txtAdditionalCharge.ForeColor = System.Drawing.Color.Black
        Me.txtAdditionalCharge.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtAdditionalCharge.HoverState.Parent = Me.txtAdditionalCharge
        Me.txtAdditionalCharge.Location = New System.Drawing.Point(606, 90)
        Me.txtAdditionalCharge.Name = "txtAdditionalCharge"
        Me.txtAdditionalCharge.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtAdditionalCharge.PlaceholderForeColor = System.Drawing.Color.Black
        Me.txtAdditionalCharge.PlaceholderText = ""
        Me.txtAdditionalCharge.SelectedText = ""
        Me.txtAdditionalCharge.SelectionStart = 1
        Me.txtAdditionalCharge.ShadowDecoration.Parent = Me.txtAdditionalCharge
        Me.txtAdditionalCharge.Size = New System.Drawing.Size(270, 34)
        Me.txtAdditionalCharge.TabIndex = 38
        Me.txtAdditionalCharge.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.Black
        Me.Label9.Location = New System.Drawing.Point(440, 96)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(160, 21)
        Me.Label9.TabIndex = 37
        Me.Label9.Text = "Additional Charge:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.Black
        Me.Label8.Location = New System.Drawing.Point(509, 56)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(84, 21)
        Me.Label8.TabIndex = 36
        Me.Label8.Text = "Quantity:"
        '
        'nmrc_qty
        '
        Me.nmrc_qty.BackColor = System.Drawing.Color.Transparent
        Me.nmrc_qty.BorderRadius = 10
        Me.nmrc_qty.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.nmrc_qty.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.nmrc_qty.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.nmrc_qty.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.nmrc_qty.DisabledState.Parent = Me.nmrc_qty
        Me.nmrc_qty.DisabledState.UpDownButtonFillColor = System.Drawing.Color.FromArgb(CType(CType(177, Byte), Integer), CType(CType(177, Byte), Integer), CType(CType(177, Byte), Integer))
        Me.nmrc_qty.DisabledState.UpDownButtonForeColor = System.Drawing.Color.FromArgb(CType(CType(203, Byte), Integer), CType(CType(203, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.nmrc_qty.Enabled = False
        Me.nmrc_qty.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.nmrc_qty.FocusedState.Parent = Me.nmrc_qty
        Me.nmrc_qty.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.nmrc_qty.ForeColor = System.Drawing.Color.FromArgb(CType(CType(126, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.nmrc_qty.Location = New System.Drawing.Point(606, 48)
        Me.nmrc_qty.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.nmrc_qty.Name = "nmrc_qty"
        Me.nmrc_qty.ShadowDecoration.Parent = Me.nmrc_qty
        Me.nmrc_qty.Size = New System.Drawing.Size(270, 36)
        Me.nmrc_qty.TabIndex = 35
        Me.nmrc_qty.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'lblItemCost
        '
        Me.lblItemCost.AutoSize = True
        Me.lblItemCost.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblItemCost.ForeColor = System.Drawing.Color.Black
        Me.lblItemCost.Location = New System.Drawing.Point(606, 173)
        Me.lblItemCost.Name = "lblItemCost"
        Me.lblItemCost.Size = New System.Drawing.Size(31, 21)
        Me.lblItemCost.TabIndex = 34
        Me.lblItemCost.Text = "[?]"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.Location = New System.Drawing.Point(502, 173)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(91, 21)
        Me.Label1.TabIndex = 33
        Me.Label1.Text = "Item Cost:"
        '
        'lblItemName
        '
        Me.lblItemName.AutoSize = True
        Me.lblItemName.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblItemName.ForeColor = System.Drawing.Color.Black
        Me.lblItemName.Location = New System.Drawing.Point(606, 151)
        Me.lblItemName.Name = "lblItemName"
        Me.lblItemName.Size = New System.Drawing.Size(31, 21)
        Me.lblItemName.TabIndex = 32
        Me.lblItemName.Text = "[?]"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(490, 151)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(103, 21)
        Me.Label2.TabIndex = 31
        Me.Label2.Text = "Item Name:"
        '
        'btnBrowsePatient
        '
        Me.btnBrowsePatient.BorderRadius = 20
        Me.btnBrowsePatient.CheckedState.Parent = Me.btnBrowsePatient
        Me.btnBrowsePatient.CustomImages.Parent = Me.btnBrowsePatient
        Me.btnBrowsePatient.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.btnBrowsePatient.ForeColor = System.Drawing.Color.White
        Me.btnBrowsePatient.HoverState.Parent = Me.btnBrowsePatient
        Me.btnBrowsePatient.Location = New System.Drawing.Point(298, 56)
        Me.btnBrowsePatient.Name = "btnBrowsePatient"
        Me.btnBrowsePatient.ShadowDecoration.Parent = Me.btnBrowsePatient
        Me.btnBrowsePatient.Size = New System.Drawing.Size(101, 38)
        Me.btnBrowsePatient.TabIndex = 30
        Me.btnBrowsePatient.Text = "Browse"
        '
        'btnBrowseItem
        '
        Me.btnBrowseItem.BorderRadius = 20
        Me.btnBrowseItem.CheckedState.Parent = Me.btnBrowseItem
        Me.btnBrowseItem.CustomImages.Parent = Me.btnBrowseItem
        Me.btnBrowseItem.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.btnBrowseItem.ForeColor = System.Drawing.Color.White
        Me.btnBrowseItem.HoverState.Parent = Me.btnBrowseItem
        Me.btnBrowseItem.Location = New System.Drawing.Point(298, 112)
        Me.btnBrowseItem.Name = "btnBrowseItem"
        Me.btnBrowseItem.ShadowDecoration.Parent = Me.btnBrowseItem
        Me.btnBrowseItem.Size = New System.Drawing.Size(101, 38)
        Me.btnBrowseItem.TabIndex = 29
        Me.btnBrowseItem.Text = "Browse"
        '
        'txtItemID
        '
        Me.txtItemID.BorderColor = System.Drawing.SystemColors.ControlDark
        Me.txtItemID.BorderRadius = 10
        Me.txtItemID.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtItemID.DefaultText = ""
        Me.txtItemID.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.txtItemID.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.txtItemID.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtItemID.DisabledState.Parent = Me.txtItemID
        Me.txtItemID.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtItemID.Enabled = False
        Me.txtItemID.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtItemID.FocusedState.Parent = Me.txtItemID
        Me.txtItemID.ForeColor = System.Drawing.Color.Black
        Me.txtItemID.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtItemID.HoverState.Parent = Me.txtItemID
        Me.txtItemID.Location = New System.Drawing.Point(16, 112)
        Me.txtItemID.Name = "txtItemID"
        Me.txtItemID.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtItemID.PlaceholderForeColor = System.Drawing.Color.Black
        Me.txtItemID.PlaceholderText = "Item"
        Me.txtItemID.SelectedText = ""
        Me.txtItemID.ShadowDecoration.Parent = Me.txtItemID
        Me.txtItemID.Size = New System.Drawing.Size(276, 38)
        Me.txtItemID.TabIndex = 28
        '
        'lblPatientName
        '
        Me.lblPatientName.AutoSize = True
        Me.lblPatientName.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPatientName.ForeColor = System.Drawing.Color.Black
        Me.lblPatientName.Location = New System.Drawing.Point(606, 128)
        Me.lblPatientName.Name = "lblPatientName"
        Me.lblPatientName.Size = New System.Drawing.Size(31, 21)
        Me.lblPatientName.TabIndex = 27
        Me.lblPatientName.Text = "[?]"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(470, 128)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(123, 21)
        Me.Label3.TabIndex = 26
        Me.Label3.Text = "Patient Name:"
        '
        'txtPatientID
        '
        Me.txtPatientID.BorderColor = System.Drawing.SystemColors.ControlDark
        Me.txtPatientID.BorderRadius = 10
        Me.txtPatientID.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtPatientID.DefaultText = ""
        Me.txtPatientID.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.txtPatientID.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.txtPatientID.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtPatientID.DisabledState.Parent = Me.txtPatientID
        Me.txtPatientID.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtPatientID.Enabled = False
        Me.txtPatientID.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtPatientID.FocusedState.Parent = Me.txtPatientID
        Me.txtPatientID.ForeColor = System.Drawing.Color.Black
        Me.txtPatientID.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtPatientID.HoverState.Parent = Me.txtPatientID
        Me.txtPatientID.Location = New System.Drawing.Point(16, 56)
        Me.txtPatientID.Name = "txtPatientID"
        Me.txtPatientID.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtPatientID.PlaceholderForeColor = System.Drawing.Color.Black
        Me.txtPatientID.PlaceholderText = "Patient ID"
        Me.txtPatientID.SelectedText = ""
        Me.txtPatientID.ShadowDecoration.Parent = Me.txtPatientID
        Me.txtPatientID.Size = New System.Drawing.Size(276, 38)
        Me.txtPatientID.TabIndex = 25
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.dgvItemCart)
        Me.Panel1.Location = New System.Drawing.Point(12, 220)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(885, 306)
        Me.Panel1.TabIndex = 33
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label5.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(14, 15)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(54, 19)
        Me.Label5.TabIndex = 3
        Me.Label5.Text = "Actions"
        '
        'dgvItemCart
        '
        Me.dgvItemCart.AllowUserToAddRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.White
        Me.dgvItemCart.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.dgvItemCart.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvItemCart.BackgroundColor = System.Drawing.Color.White
        Me.dgvItemCart.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.dgvItemCart.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.dgvItemCart.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvItemCart.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.dgvItemCart.ColumnHeadersHeight = 50
        Me.dgvItemCart.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.dgvItemCart.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.action_delete})
        Me.dgvItemCart.Cursor = System.Windows.Forms.Cursors.Hand
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        DataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(71, Byte), Integer), CType(CType(69, Byte), Integer), CType(CType(94, Byte), Integer))
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(229, Byte), Integer), CType(CType(255, Byte), Integer))
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(71, Byte), Integer), CType(CType(69, Byte), Integer), CType(CType(94, Byte), Integer))
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvItemCart.DefaultCellStyle = DataGridViewCellStyle3
        Me.dgvItemCart.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgvItemCart.EnableHeadersVisualStyles = False
        Me.dgvItemCart.GridColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(229, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.dgvItemCart.Location = New System.Drawing.Point(0, 0)
        Me.dgvItemCart.Name = "dgvItemCart"
        Me.dgvItemCart.ReadOnly = True
        Me.dgvItemCart.RowHeadersVisible = False
        Me.dgvItemCart.RowTemplate.Height = 80
        Me.dgvItemCart.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvItemCart.Size = New System.Drawing.Size(885, 306)
        Me.dgvItemCart.TabIndex = 2
        Me.dgvItemCart.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.[Default]
        Me.dgvItemCart.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White
        Me.dgvItemCart.ThemeStyle.AlternatingRowsStyle.Font = Nothing
        Me.dgvItemCart.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty
        Me.dgvItemCart.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty
        Me.dgvItemCart.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty
        Me.dgvItemCart.ThemeStyle.BackColor = System.Drawing.Color.White
        Me.dgvItemCart.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(229, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.dgvItemCart.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.dgvItemCart.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.dgvItemCart.ThemeStyle.HeaderStyle.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        Me.dgvItemCart.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White
        Me.dgvItemCart.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.dgvItemCart.ThemeStyle.HeaderStyle.Height = 50
        Me.dgvItemCart.ThemeStyle.ReadOnly = True
        Me.dgvItemCart.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White
        Me.dgvItemCart.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.dgvItemCart.ThemeStyle.RowsStyle.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        Me.dgvItemCart.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(71, Byte), Integer), CType(CType(69, Byte), Integer), CType(CType(94, Byte), Integer))
        Me.dgvItemCart.ThemeStyle.RowsStyle.Height = 80
        Me.dgvItemCart.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(229, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.dgvItemCart.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(71, Byte), Integer), CType(CType(69, Byte), Integer), CType(CType(94, Byte), Integer))
        '
        'action_delete
        '
        Me.action_delete.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        Me.action_delete.DividerWidth = 2
        Me.action_delete.Frozen = True
        Me.action_delete.HeaderText = ""
        Me.action_delete.Image = CType(resources.GetObject("action_delete.Image"), System.Drawing.Image)
        Me.action_delete.Name = "action_delete"
        Me.action_delete.ReadOnly = True
        Me.action_delete.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.action_delete.ToolTipText = "Delete"
        Me.action_delete.Width = 90
        '
        'btnConfirmTransaction
        '
        Me.btnConfirmTransaction.BorderRadius = 20
        Me.btnConfirmTransaction.CheckedState.Parent = Me.btnConfirmTransaction
        Me.btnConfirmTransaction.CustomImages.Parent = Me.btnConfirmTransaction
        Me.btnConfirmTransaction.FillColor = System.Drawing.Color.SeaGreen
        Me.btnConfirmTransaction.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.btnConfirmTransaction.ForeColor = System.Drawing.Color.White
        Me.btnConfirmTransaction.HoverState.Parent = Me.btnConfirmTransaction
        Me.btnConfirmTransaction.Location = New System.Drawing.Point(97, 529)
        Me.btnConfirmTransaction.Name = "btnConfirmTransaction"
        Me.btnConfirmTransaction.ShadowDecoration.Parent = Me.btnConfirmTransaction
        Me.btnConfirmTransaction.Size = New System.Drawing.Size(160, 38)
        Me.btnConfirmTransaction.TabIndex = 40
        Me.btnConfirmTransaction.Text = "Confirm Transaction"
        Me.btnConfirmTransaction.Visible = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Century Gothic", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(542, 526)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(148, 36)
        Me.Label6.TabIndex = 41
        Me.Label6.Text = "Sub Total:"
        '
        'txtSubtotal
        '
        Me.txtSubtotal.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtSubtotal.DefaultText = ""
        Me.txtSubtotal.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.txtSubtotal.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.txtSubtotal.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtSubtotal.DisabledState.Parent = Me.txtSubtotal
        Me.txtSubtotal.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtSubtotal.Enabled = False
        Me.txtSubtotal.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtSubtotal.FocusedState.Parent = Me.txtSubtotal
        Me.txtSubtotal.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSubtotal.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtSubtotal.HoverState.Parent = Me.txtSubtotal
        Me.txtSubtotal.Location = New System.Drawing.Point(697, 527)
        Me.txtSubtotal.Margin = New System.Windows.Forms.Padding(5, 5, 5, 5)
        Me.txtSubtotal.Name = "txtSubtotal"
        Me.txtSubtotal.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtSubtotal.PlaceholderText = ""
        Me.txtSubtotal.SelectedText = ""
        Me.txtSubtotal.ShadowDecoration.Parent = Me.txtSubtotal
        Me.txtSubtotal.Size = New System.Drawing.Size(200, 36)
        Me.txtSubtotal.TabIndex = 42
        Me.txtSubtotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'btnDeleteTransaction
        '
        Me.btnDeleteTransaction.BorderRadius = 20
        Me.btnDeleteTransaction.CheckedState.Parent = Me.btnDeleteTransaction
        Me.btnDeleteTransaction.CustomImages.Parent = Me.btnDeleteTransaction
        Me.btnDeleteTransaction.FillColor = System.Drawing.Color.Firebrick
        Me.btnDeleteTransaction.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.btnDeleteTransaction.ForeColor = System.Drawing.Color.White
        Me.btnDeleteTransaction.HoverState.Parent = Me.btnDeleteTransaction
        Me.btnDeleteTransaction.Location = New System.Drawing.Point(288, 529)
        Me.btnDeleteTransaction.Name = "btnDeleteTransaction"
        Me.btnDeleteTransaction.ShadowDecoration.Parent = Me.btnDeleteTransaction
        Me.btnDeleteTransaction.Size = New System.Drawing.Size(160, 38)
        Me.btnDeleteTransaction.TabIndex = 43
        Me.btnDeleteTransaction.Text = "Delete Transaction"
        Me.btnDeleteTransaction.Visible = False
        '
        'UserControl_transaction_item
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.Controls.Add(Me.btnDeleteTransaction)
        Me.Controls.Add(Me.txtSubtotal)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.btnConfirmTransaction)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Guna2GroupBox1)
        Me.Name = "UserControl_transaction_item"
        Me.Size = New System.Drawing.Size(909, 578)
        Me.Guna2GroupBox1.ResumeLayout(False)
        Me.Guna2GroupBox1.PerformLayout()
        CType(Me.nmrc_qty, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.dgvItemCart, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Guna2GroupBox1 As Guna.UI2.WinForms.Guna2GroupBox
    Friend WithEvents lblItemCost As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents lblItemName As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents btnBrowsePatient As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents btnBrowseItem As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents txtItemID As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents lblPatientName As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents txtPatientID As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents nmrc_qty As Guna.UI2.WinForms.Guna2NumericUpDown
    Friend WithEvents txtAdditionalCharge As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents Guna2Button4 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button3 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents btnConfirmTransaction As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Label4 As Label
    Friend WithEvents dgvItemCart As Guna.UI2.WinForms.Guna2DataGridView
    Friend WithEvents action_delete As DataGridViewImageColumn
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents txtSubtotal As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents btnDeleteTransaction As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents txtTransactionNo As Guna.UI2.WinForms.Guna2TextBox
End Class
