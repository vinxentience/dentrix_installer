﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frm_confirm_payment_balance
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Guna2Button5 = New Guna.UI2.WinForms.Guna2Button()
        Me.txtTotalBalance = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtTotalChange = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtAmountReceive = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Guna2Button5
        '
        Me.Guna2Button5.BorderRadius = 20
        Me.Guna2Button5.CheckedState.Parent = Me.Guna2Button5
        Me.Guna2Button5.CustomImages.Parent = Me.Guna2Button5
        Me.Guna2Button5.FillColor = System.Drawing.Color.SeaGreen
        Me.Guna2Button5.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2Button5.ForeColor = System.Drawing.Color.White
        Me.Guna2Button5.HoverState.Parent = Me.Guna2Button5
        Me.Guna2Button5.Location = New System.Drawing.Point(169, 229)
        Me.Guna2Button5.Name = "Guna2Button5"
        Me.Guna2Button5.ShadowDecoration.Parent = Me.Guna2Button5
        Me.Guna2Button5.Size = New System.Drawing.Size(160, 38)
        Me.Guna2Button5.TabIndex = 48
        Me.Guna2Button5.Text = "Confirm"
        '
        'txtTotalBalance
        '
        Me.txtTotalBalance.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtTotalBalance.DefaultText = ""
        Me.txtTotalBalance.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.txtTotalBalance.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.txtTotalBalance.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtTotalBalance.DisabledState.Parent = Me.txtTotalBalance
        Me.txtTotalBalance.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtTotalBalance.Enabled = False
        Me.txtTotalBalance.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtTotalBalance.FocusedState.Parent = Me.txtTotalBalance
        Me.txtTotalBalance.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtTotalBalance.HoverState.Parent = Me.txtTotalBalance
        Me.txtTotalBalance.Location = New System.Drawing.Point(213, 151)
        Me.txtTotalBalance.Name = "txtTotalBalance"
        Me.txtTotalBalance.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtTotalBalance.PlaceholderText = ""
        Me.txtTotalBalance.SelectedText = ""
        Me.txtTotalBalance.ShadowDecoration.Parent = Me.txtTotalBalance
        Me.txtTotalBalance.Size = New System.Drawing.Size(274, 36)
        Me.txtTotalBalance.TabIndex = 47
        Me.txtTotalBalance.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(71, 104)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(122, 21)
        Me.Label3.TabIndex = 46
        Me.Label3.Text = "Total Change:"
        '
        'txtTotalChange
        '
        Me.txtTotalChange.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtTotalChange.DefaultText = ""
        Me.txtTotalChange.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.txtTotalChange.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.txtTotalChange.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtTotalChange.DisabledState.Parent = Me.txtTotalChange
        Me.txtTotalChange.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtTotalChange.Enabled = False
        Me.txtTotalChange.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtTotalChange.FocusedState.Parent = Me.txtTotalChange
        Me.txtTotalChange.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtTotalChange.HoverState.Parent = Me.txtTotalChange
        Me.txtTotalChange.Location = New System.Drawing.Point(213, 97)
        Me.txtTotalChange.Name = "txtTotalChange"
        Me.txtTotalChange.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtTotalChange.PlaceholderText = ""
        Me.txtTotalChange.SelectedText = ""
        Me.txtTotalChange.ShadowDecoration.Parent = Me.txtTotalChange
        Me.txtTotalChange.Size = New System.Drawing.Size(274, 36)
        Me.txtTotalChange.TabIndex = 45
        Me.txtTotalChange.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(46, 161)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(147, 21)
        Me.Label2.TabIndex = 44
        Me.Label2.Text = "Balance Amount:"
        '
        'txtAmountReceive
        '
        Me.txtAmountReceive.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtAmountReceive.DefaultText = ""
        Me.txtAmountReceive.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.txtAmountReceive.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.txtAmountReceive.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtAmountReceive.DisabledState.Parent = Me.txtAmountReceive
        Me.txtAmountReceive.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtAmountReceive.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtAmountReceive.FocusedState.Parent = Me.txtAmountReceive
        Me.txtAmountReceive.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtAmountReceive.HoverState.Parent = Me.txtAmountReceive
        Me.txtAmountReceive.Location = New System.Drawing.Point(213, 37)
        Me.txtAmountReceive.Name = "txtAmountReceive"
        Me.txtAmountReceive.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtAmountReceive.PlaceholderText = ""
        Me.txtAmountReceive.SelectedText = ""
        Me.txtAmountReceive.ShadowDecoration.Parent = Me.txtAmountReceive
        Me.txtAmountReceive.Size = New System.Drawing.Size(274, 36)
        Me.txtAmountReceive.TabIndex = 43
        Me.txtAmountReceive.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(36, 45)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(157, 21)
        Me.Label1.TabIndex = 42
        Me.Label1.Text = "Amount Received:"
        '
        'frm_confirm_payment_balance
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(520, 279)
        Me.Controls.Add(Me.Guna2Button5)
        Me.Controls.Add(Me.txtTotalBalance)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtTotalChange)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtAmountReceive)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "frm_confirm_payment_balance"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Pay Balance"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Guna2Button5 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents txtTotalBalance As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtTotalChange As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txtAmountReceive As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Label1 As Label
End Class
