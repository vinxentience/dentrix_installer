﻿Imports MySql.Data.MySqlClient

Public Class frm_confirm_payment
    Public subtotal As Double
    Dim received As Double
    Public patient_payer As Integer
    Public transaction_no As Integer
    Public isSubmitted As Boolean
    Public transaction_type As String
    Dim isPaid As String
    Private Sub Guna2TextBox1_TextChanged(sender As Object, e As EventArgs) Handles txtAmountReceive.TextChanged
        Try
            If (IsNumeric(txtAmountReceive.Text) = False And txtAmountReceive.Text <> "") Then
                MsgBox("Amount Receive must be numeric")
                txtAmountReceive.Clear()
            End If
            received = CDbl(txtAmountReceive.Text) + 0
            If txtAmountReceive.Text = "" Or received = 0 Then
            ElseIf received < subtotal Then
                txtTotalBalance.Text = Math.Round(subtotal - received, 2)
                txtTotalChange.Text = ""
                isPaid = "false"
            ElseIf received > subtotal Then
                txtTotalChange.Text = Math.Round(received - subtotal, 2)
                txtTotalBalance.Text = ""
                isPaid = "true"
            Else
                txtTotalChange.Text = ""
                txtTotalBalance.Text = ""
                isPaid = "true"
            End If
        Catch ex As Exception
            txtTotalChange.Clear()
            txtTotalBalance.Clear()
            received = 0
        End Try

    End Sub

    Private Sub Guna2Button5_Click(sender As Object, e As EventArgs) Handles Guna2Button5.Click
        Dim dialogResult As DialogResult = MessageBox.Show("Do you want to save this transaction?", "Transaction", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If txtAmountReceive.Text = "" Or received = 0 Then
            MsgBox("Amount receive is empty.")
        Else
            If dialogResult = DialogResult.Yes Then
                conn.Open()
                If transaction_type = "Item" Then
                    Try
                        comm = New MySqlCommand("prcInsertTransactionItemRelationship", conn)
                        With comm
                            .CommandType = CommandType.StoredProcedure
                            .Parameters.AddWithValue("@did", user_id)
                            .Parameters.AddWithValue("@pid", patient_payer)
                            .Parameters.AddWithValue("@tid", transaction_no)
                            .Parameters.AddWithValue("@stotal", subtotal)
                            .Parameters.AddWithValue("@amt", received)
                            .Parameters.AddWithValue("@tdate", Format(Date.Now, "yyyy-MM-dd"))
                            .Parameters.AddWithValue("@ipaid", isPaid)
                            .ExecuteNonQuery()
                        End With

                        If received < subtotal Then
                            add_balance_item(user_id, patient_payer, transaction_no)
                        End If

                        isSubmitted = True

                    Catch ex As Exception

                    End Try
                ElseIf transaction_type = "Service" Then
                    Try
                        comm = New MySqlCommand("prcInsertTransactionServiceRelationship", conn)
                        With comm
                            .CommandType = CommandType.StoredProcedure
                            .Parameters.AddWithValue("@did", user_id)
                            .Parameters.AddWithValue("@pid", patient_payer)
                            .Parameters.AddWithValue("@tid", transaction_no)
                            .Parameters.AddWithValue("@stotal", subtotal)
                            .Parameters.AddWithValue("@amt", received)
                            .Parameters.AddWithValue("@tdate", Format(Date.Now, "yyyy-MM-dd"))
                            .Parameters.AddWithValue("@ipaid", isPaid)
                            .ExecuteNonQuery()
                        End With

                        If received < subtotal Then
                            add_balance_service(user_id, patient_payer, transaction_no)
                        End If

                        isSubmitted = True

                    Catch ex As Exception
                        MsgBox(ex.Message)
                    End Try
                Else
                    isSubmitted = False
                End If
                txtTotalBalance.Clear()
                txtTotalChange.Clear()
                conn.Close()
                insertToLogs(user_id, "transaction (" & transaction_type & ")", "payment", u_employee, "User added transaction (" & transaction_type & ") payment of patient id: " & patient_payer)
                Me.Close()
            End If
        End If
    End Sub

    Private Sub add_balance_service(ByVal did As Integer, ByVal pid As Integer, ByVal tid As Integer)
        Try
            comm = New MySqlCommand("prcInsertBalanceAmount_Service", conn)
            With comm
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@did", did)
                .Parameters.AddWithValue("@pid", pid)
                .Parameters.AddWithValue("@tid", tid)
                .Parameters.AddWithValue("@bamt", txtTotalBalance.Text)
                .Parameters.AddWithValue("@received", received)
                .Parameters.AddWithValue("@lpayment", Format(Date.Now, "yyyy-MM-dd"))
                .ExecuteNonQuery()
            End With
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub add_balance_item(ByVal did As Integer, ByVal pid As Integer, ByVal tid As Integer)
        Try
            comm = New MySqlCommand("prcInsertBalanceAmount_Item", conn)
            With comm
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@did", did)
                .Parameters.AddWithValue("@pid", pid)
                .Parameters.AddWithValue("@tid", tid)
                .Parameters.AddWithValue("@bamt", txtTotalBalance.Text)
                .Parameters.AddWithValue("@received", received)
                .Parameters.AddWithValue("@lpayment", Format(Date.Now, "yyyy-MM-dd"))
                .ExecuteNonQuery()
            End With
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub frm_confirm_payment_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        If isSubmitted = True Then
            isSubmitted = True
        Else
            isSubmitted = False
        End If
        Me.Dispose()
    End Sub

End Class