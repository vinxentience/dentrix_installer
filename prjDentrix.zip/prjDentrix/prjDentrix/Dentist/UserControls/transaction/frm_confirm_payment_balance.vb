﻿Imports MySql.Data.MySqlClient

Public Class frm_confirm_payment_balance
    Public bamt As Double
    Public stotal As Double
    Public received As Double
    Public amount_paid As Double
    Public tid As Integer
    Public pid As Integer
    Public transaction_type As String
    Private Sub frm_confirm_payment_balance_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtAmountReceive.Focus()
    End Sub

    Private Sub txtAmountReceive_TextChanged(sender As Object, e As EventArgs) Handles txtAmountReceive.TextChanged
        Try
            If (IsNumeric(txtAmountReceive.Text) = False And txtAmountReceive.Text <> "") Then
                MsgBox("Amount Receive must be numeric")
                txtAmountReceive.Clear()
            End If

            received = CDbl(txtAmountReceive.Text) + 0.0
            If received < bamt Then
                txtTotalBalance.Text = Math.Round(bamt - received, 2)
                txtTotalChange.Text = ""
            ElseIf received > bamt Then
                txtTotalChange.Text = Math.Round(received - bamt, 2)
                txtTotalBalance.Text = ""
            Else
                txtTotalChange.Text = ""
                txtTotalBalance.Text = ""
            End If

        Catch ex As Exception
            txtTotalChange.Clear()
            txtTotalBalance.Clear()
            received = 0
        End Try
    End Sub

    Private Sub updateTotalBalance(ByVal newBalance As Double, ByVal amtReceived As Double)
        If transaction_type = "Service" Then
            conn.Open()
            Try
                comm = New MySqlCommand("prcUpdateBalanceAmountService", conn)
                With comm
                    .CommandType = CommandType.StoredProcedure
                    .Parameters.AddWithValue("@tid", tid)
                    .Parameters.AddWithValue("@did", user_id)
                    .Parameters.AddWithValue("@pid", pid)
                    .Parameters.AddWithValue("@bamt", newBalance)
                    .Parameters.AddWithValue("@paid", amount_paid)
                    .Parameters.AddWithValue("@received", amtReceived)
                    .Parameters.AddWithValue("@lpay", Date.Now)
                    .Parameters.AddWithValue("@ipaid", False)
                    .ExecuteNonQuery()
                End With
            Catch ex As Exception
                MsgBox(ex.Message)
                conn.Close()
            End Try
            conn.Close()
        Else
            conn.Open()
            Try
                comm = New MySqlCommand("prcUpdateBalanceAmountItem", conn)
                With comm
                    .CommandType = CommandType.StoredProcedure
                    .Parameters.AddWithValue("@tid", tid)
                    .Parameters.AddWithValue("@did", user_id)
                    .Parameters.AddWithValue("@pid", pid)
                    .Parameters.AddWithValue("@bamt", newBalance)
                    .Parameters.AddWithValue("@paid", amount_paid)
                    .Parameters.AddWithValue("@received", amtReceived)
                    .Parameters.AddWithValue("@lpay", Date.Now)
                    .Parameters.AddWithValue("@ipaid", False)
                    .ExecuteNonQuery()
                End With
            Catch ex As Exception
                MsgBox(ex.Message)
                conn.Close()
            End Try
            conn.Close()
        End If

    End Sub

    Private Sub updateFullyPaid(ByVal newBalance As Double, ByVal amtReceived As Double)
        If transaction_type = "Service" Then
            conn.Open()
            Try
                comm = New MySqlCommand("prcUpdateBalanceAmountService", conn)
                With comm
                    .CommandType = CommandType.StoredProcedure
                    .Parameters.AddWithValue("@tid", tid)
                    .Parameters.AddWithValue("@did", user_id)
                    .Parameters.AddWithValue("@pid", pid)
                    .Parameters.AddWithValue("@bamt", 0)
                    .Parameters.AddWithValue("@paid", amount_paid)
                    .Parameters.AddWithValue("@received", amtReceived)
                    .Parameters.AddWithValue("@lpay", Date.Now)
                    .Parameters.AddWithValue("@ipaid", True)
                    .ExecuteNonQuery()
                End With
            Catch ex As Exception
                MsgBox(ex.Message)
                conn.Close()
            End Try
            conn.Close()
        Else
            conn.Open()
            Try
                comm = New MySqlCommand("prcUpdateBalanceAmountItem", conn)
                With comm
                    .CommandType = CommandType.StoredProcedure
                    .Parameters.AddWithValue("@tid", tid)
                    .Parameters.AddWithValue("@did", user_id)
                    .Parameters.AddWithValue("@pid", pid)
                    .Parameters.AddWithValue("@bamt", 0)
                    .Parameters.AddWithValue("@paid", amount_paid)
                    .Parameters.AddWithValue("@received", amtReceived)
                    .Parameters.AddWithValue("@lpay", Date.Now)
                    .Parameters.AddWithValue("@ipaid", True)
                    .ExecuteNonQuery()
                End With
            Catch ex As Exception
                MsgBox(ex.Message)
                conn.Close()
            End Try
            conn.Close()
        End If

    End Sub

    Private Sub frm_confirm_payment_balance_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        Me.Dispose()
    End Sub

    Private Sub Guna2Button5_Click(sender As Object, e As EventArgs) Handles Guna2Button5.Click
        Dim dialogResult As DialogResult = MessageBox.Show("Do you want to save this record? You can't edit the transaction once saved.", "Transaction", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If txtAmountReceive.Text = "" Or received = 0 Then
            MsgBox("Amount receive is empty.")
        Else
            If dialogResult = DialogResult.Yes And txtAmountReceive.Text <> "" Then
                If txtAmountReceive.Text = "" Or received = 0 Then
                    txtTotalChange.Text = ""
                    txtTotalBalance.Text = ""
                    received = 0
                ElseIf received < bamt Then
                    txtTotalBalance.Text = bamt - received
                    updateTotalBalance(txtTotalBalance.Text, txtAmountReceive.Text)
                ElseIf received > bamt Then
                    txtTotalChange.Text = received - bamt
                    txtTotalBalance.Text = ""
                    updateFullyPaid(txtTotalChange.Text, txtAmountReceive.Text)
                Else
                    txtTotalChange.Text = ""
                    txtTotalBalance.Text = ""
                    updateFullyPaid(0, txtAmountReceive.Text)
                End If
                insertToHistory(txtAmountReceive.Text)

            End If
            Me.Close()
        End If


    End Sub

    Private Sub insertToHistory(ByVal amt_received As Double)
        If transaction_type = "Service" Then
            conn.Open()
            Try
                comm = New MySqlCommand("prcInsertToBalanceHistoryService", conn)
                With comm
                    .CommandType = CommandType.StoredProcedure
                    .Parameters.AddWithValue("@did", user_id)
                    .Parameters.AddWithValue("@pid", pid)
                    .Parameters.AddWithValue("@tid", tid)
                    .Parameters.AddWithValue("@apaid", amt_received)
                    .Parameters.AddWithValue("@tdate", Date.Now)
                    .ExecuteNonQuery()
                End With
            Catch ex As Exception
                MsgBox(ex.Message)
                conn.Close()
            End Try
            conn.Close()
            insertToLogs(user_id, "balance (Service)", "payment", u_employee, "User added balance (service) payment of patient id: " & pid)
        Else
            conn.Open()
            Try
                comm = New MySqlCommand("prcInsertToBalanceHistoryItem", conn)
                With comm
                    .CommandType = CommandType.StoredProcedure
                    .Parameters.AddWithValue("@did", user_id)
                    .Parameters.AddWithValue("@pid", pid)
                    .Parameters.AddWithValue("@tid", tid)
                    .Parameters.AddWithValue("@apaid", amt_received)
                    .Parameters.AddWithValue("@tdate", Date.Now)
                    .ExecuteNonQuery()
                End With
            Catch ex As Exception
                MsgBox(ex.Message)
                conn.Close()
            End Try
            conn.Close()
            insertToLogs(user_id, "balance (Item)", "payment", u_employee, "User added balance (item) payment of patient id: " & pid)
        End If

    End Sub

End Class