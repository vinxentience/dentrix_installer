﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class UserControl_transaction_service
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(UserControl_transaction_service))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.dgvServiceCart = New Guna.UI2.WinForms.Guna2DataGridView()
        Me.action_delete = New System.Windows.Forms.DataGridViewImageColumn()
        Me.txtTransactionNo = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Guna2Button4 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button3 = New Guna.UI2.WinForms.Guna2Button()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.btnConfirmTransaction = New Guna.UI2.WinForms.Guna2Button()
        Me.lblServiceCost = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblIServiceName = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnDeleteTransaction = New Guna.UI2.WinForms.Guna2Button()
        Me.btnBrowsePatient = New Guna.UI2.WinForms.Guna2Button()
        Me.btnBrowseItem = New Guna.UI2.WinForms.Guna2Button()
        Me.txtServiceID = New Guna.UI2.WinForms.Guna2TextBox()
        Me.lblPatientName = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtSubtotal = New Guna.UI2.WinForms.Guna2TextBox()
        Me.txtPatientID = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2GroupBox1 = New Guna.UI2.WinForms.Guna2GroupBox()
        Me.txtAdditionalCharge = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Panel1.SuspendLayout()
        CType(Me.dgvServiceCart, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Guna2GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.dgvServiceCart)
        Me.Panel1.Location = New System.Drawing.Point(12, 220)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(885, 306)
        Me.Panel1.TabIndex = 45
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label5.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(14, 15)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(54, 19)
        Me.Label5.TabIndex = 3
        Me.Label5.Text = "Actions"
        '
        'dgvServiceCart
        '
        Me.dgvServiceCart.AllowUserToAddRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.White
        Me.dgvServiceCart.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.dgvServiceCart.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvServiceCart.BackgroundColor = System.Drawing.Color.White
        Me.dgvServiceCart.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.dgvServiceCart.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.dgvServiceCart.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvServiceCart.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.dgvServiceCart.ColumnHeadersHeight = 50
        Me.dgvServiceCart.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.dgvServiceCart.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.action_delete})
        Me.dgvServiceCart.Cursor = System.Windows.Forms.Cursors.Hand
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        DataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(71, Byte), Integer), CType(CType(69, Byte), Integer), CType(CType(94, Byte), Integer))
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(229, Byte), Integer), CType(CType(255, Byte), Integer))
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(71, Byte), Integer), CType(CType(69, Byte), Integer), CType(CType(94, Byte), Integer))
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvServiceCart.DefaultCellStyle = DataGridViewCellStyle3
        Me.dgvServiceCart.EnableHeadersVisualStyles = False
        Me.dgvServiceCart.GridColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(229, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.dgvServiceCart.Location = New System.Drawing.Point(0, 0)
        Me.dgvServiceCart.Name = "dgvServiceCart"
        Me.dgvServiceCart.ReadOnly = True
        Me.dgvServiceCart.RowHeadersVisible = False
        Me.dgvServiceCart.RowTemplate.Height = 80
        Me.dgvServiceCart.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvServiceCart.Size = New System.Drawing.Size(885, 306)
        Me.dgvServiceCart.TabIndex = 2
        Me.dgvServiceCart.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.[Default]
        Me.dgvServiceCart.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White
        Me.dgvServiceCart.ThemeStyle.AlternatingRowsStyle.Font = Nothing
        Me.dgvServiceCart.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty
        Me.dgvServiceCart.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty
        Me.dgvServiceCart.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty
        Me.dgvServiceCart.ThemeStyle.BackColor = System.Drawing.Color.White
        Me.dgvServiceCart.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(229, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.dgvServiceCart.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.dgvServiceCart.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.dgvServiceCart.ThemeStyle.HeaderStyle.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        Me.dgvServiceCart.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White
        Me.dgvServiceCart.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.dgvServiceCart.ThemeStyle.HeaderStyle.Height = 50
        Me.dgvServiceCart.ThemeStyle.ReadOnly = True
        Me.dgvServiceCart.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White
        Me.dgvServiceCart.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.dgvServiceCart.ThemeStyle.RowsStyle.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        Me.dgvServiceCart.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(71, Byte), Integer), CType(CType(69, Byte), Integer), CType(CType(94, Byte), Integer))
        Me.dgvServiceCart.ThemeStyle.RowsStyle.Height = 80
        Me.dgvServiceCart.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(229, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.dgvServiceCart.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(71, Byte), Integer), CType(CType(69, Byte), Integer), CType(CType(94, Byte), Integer))
        '
        'action_delete
        '
        Me.action_delete.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        Me.action_delete.DividerWidth = 2
        Me.action_delete.Frozen = True
        Me.action_delete.HeaderText = ""
        Me.action_delete.Image = CType(resources.GetObject("action_delete.Image"), System.Drawing.Image)
        Me.action_delete.Name = "action_delete"
        Me.action_delete.ReadOnly = True
        Me.action_delete.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.action_delete.ToolTipText = "Delete"
        Me.action_delete.Width = 90
        '
        'txtTransactionNo
        '
        Me.txtTransactionNo.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(88, Byte), Integer))
        Me.txtTransactionNo.BorderColor = System.Drawing.Color.White
        Me.txtTransactionNo.BorderRadius = 5
        Me.txtTransactionNo.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtTransactionNo.DefaultText = ""
        Me.txtTransactionNo.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.txtTransactionNo.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.txtTransactionNo.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtTransactionNo.DisabledState.Parent = Me.txtTransactionNo
        Me.txtTransactionNo.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtTransactionNo.Enabled = False
        Me.txtTransactionNo.FillColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(88, Byte), Integer))
        Me.txtTransactionNo.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtTransactionNo.FocusedState.Parent = Me.txtTransactionNo
        Me.txtTransactionNo.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTransactionNo.ForeColor = System.Drawing.Color.White
        Me.txtTransactionNo.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtTransactionNo.HoverState.Parent = Me.txtTransactionNo
        Me.txtTransactionNo.Location = New System.Drawing.Point(722, 7)
        Me.txtTransactionNo.Margin = New System.Windows.Forms.Padding(5, 5, 5, 5)
        Me.txtTransactionNo.Name = "txtTransactionNo"
        Me.txtTransactionNo.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtTransactionNo.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(88, Byte), Integer))
        Me.txtTransactionNo.PlaceholderText = ""
        Me.txtTransactionNo.SelectedText = ""
        Me.txtTransactionNo.ShadowDecoration.Parent = Me.txtTransactionNo
        Me.txtTransactionNo.Size = New System.Drawing.Size(154, 26)
        Me.txtTransactionNo.TabIndex = 43
        Me.txtTransactionNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(88, Byte), Integer))
        Me.Label4.Location = New System.Drawing.Point(629, 11)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(89, 15)
        Me.Label4.TabIndex = 41
        Me.Label4.Text = "Transaction No."
        '
        'Guna2Button4
        '
        Me.Guna2Button4.BorderRadius = 20
        Me.Guna2Button4.CheckedState.Parent = Me.Guna2Button4
        Me.Guna2Button4.CustomImages.Parent = Me.Guna2Button4
        Me.Guna2Button4.FillColor = System.Drawing.Color.SeaGreen
        Me.Guna2Button4.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2Button4.ForeColor = System.Drawing.Color.White
        Me.Guna2Button4.HoverState.Parent = Me.Guna2Button4
        Me.Guna2Button4.Location = New System.Drawing.Point(194, 156)
        Me.Guna2Button4.Name = "Guna2Button4"
        Me.Guna2Button4.ShadowDecoration.Parent = Me.Guna2Button4
        Me.Guna2Button4.Size = New System.Drawing.Size(160, 38)
        Me.Guna2Button4.TabIndex = 40
        Me.Guna2Button4.Text = "Clear"
        '
        'Guna2Button3
        '
        Me.Guna2Button3.BorderRadius = 20
        Me.Guna2Button3.CheckedState.Parent = Me.Guna2Button3
        Me.Guna2Button3.CustomImages.Parent = Me.Guna2Button3
        Me.Guna2Button3.FillColor = System.Drawing.Color.SeaGreen
        Me.Guna2Button3.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2Button3.ForeColor = System.Drawing.Color.White
        Me.Guna2Button3.HoverState.Parent = Me.Guna2Button3
        Me.Guna2Button3.Location = New System.Drawing.Point(16, 156)
        Me.Guna2Button3.Name = "Guna2Button3"
        Me.Guna2Button3.ShadowDecoration.Parent = Me.Guna2Button3
        Me.Guna2Button3.Size = New System.Drawing.Size(160, 38)
        Me.Guna2Button3.TabIndex = 39
        Me.Guna2Button3.Text = "Add Service"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.Black
        Me.Label9.Location = New System.Drawing.Point(444, 62)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(160, 21)
        Me.Label9.TabIndex = 37
        Me.Label9.Text = "Additional Charge:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Century Gothic", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(541, 527)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(148, 36)
        Me.Label6.TabIndex = 47
        Me.Label6.Text = "Sub Total:"
        '
        'btnConfirmTransaction
        '
        Me.btnConfirmTransaction.BorderRadius = 20
        Me.btnConfirmTransaction.CheckedState.Parent = Me.btnConfirmTransaction
        Me.btnConfirmTransaction.CustomImages.Parent = Me.btnConfirmTransaction
        Me.btnConfirmTransaction.FillColor = System.Drawing.Color.SeaGreen
        Me.btnConfirmTransaction.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.btnConfirmTransaction.ForeColor = System.Drawing.Color.White
        Me.btnConfirmTransaction.HoverState.Parent = Me.btnConfirmTransaction
        Me.btnConfirmTransaction.Location = New System.Drawing.Point(97, 528)
        Me.btnConfirmTransaction.Name = "btnConfirmTransaction"
        Me.btnConfirmTransaction.ShadowDecoration.Parent = Me.btnConfirmTransaction
        Me.btnConfirmTransaction.Size = New System.Drawing.Size(160, 38)
        Me.btnConfirmTransaction.TabIndex = 46
        Me.btnConfirmTransaction.Text = "Confirm Transaction"
        Me.btnConfirmTransaction.Visible = False
        '
        'lblServiceCost
        '
        Me.lblServiceCost.AutoSize = True
        Me.lblServiceCost.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblServiceCost.ForeColor = System.Drawing.Color.Black
        Me.lblServiceCost.Location = New System.Drawing.Point(617, 138)
        Me.lblServiceCost.Name = "lblServiceCost"
        Me.lblServiceCost.Size = New System.Drawing.Size(31, 21)
        Me.lblServiceCost.TabIndex = 34
        Me.lblServiceCost.Text = "[?]"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.Location = New System.Drawing.Point(494, 138)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(110, 21)
        Me.Label1.TabIndex = 33
        Me.Label1.Text = "Service Cost:"
        '
        'lblIServiceName
        '
        Me.lblIServiceName.AutoSize = True
        Me.lblIServiceName.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblIServiceName.ForeColor = System.Drawing.Color.Black
        Me.lblIServiceName.Location = New System.Drawing.Point(617, 116)
        Me.lblIServiceName.Name = "lblIServiceName"
        Me.lblIServiceName.Size = New System.Drawing.Size(31, 21)
        Me.lblIServiceName.TabIndex = 32
        Me.lblIServiceName.Text = "[?]"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(481, 116)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(122, 21)
        Me.Label2.TabIndex = 31
        Me.Label2.Text = "Service Name:"
        '
        'btnDeleteTransaction
        '
        Me.btnDeleteTransaction.BorderRadius = 20
        Me.btnDeleteTransaction.CheckedState.Parent = Me.btnDeleteTransaction
        Me.btnDeleteTransaction.CustomImages.Parent = Me.btnDeleteTransaction
        Me.btnDeleteTransaction.FillColor = System.Drawing.Color.Firebrick
        Me.btnDeleteTransaction.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.btnDeleteTransaction.ForeColor = System.Drawing.Color.White
        Me.btnDeleteTransaction.HoverState.Parent = Me.btnDeleteTransaction
        Me.btnDeleteTransaction.Location = New System.Drawing.Point(288, 528)
        Me.btnDeleteTransaction.Name = "btnDeleteTransaction"
        Me.btnDeleteTransaction.ShadowDecoration.Parent = Me.btnDeleteTransaction
        Me.btnDeleteTransaction.Size = New System.Drawing.Size(160, 38)
        Me.btnDeleteTransaction.TabIndex = 49
        Me.btnDeleteTransaction.Text = "Delete Transaction"
        Me.btnDeleteTransaction.Visible = False
        '
        'btnBrowsePatient
        '
        Me.btnBrowsePatient.BorderRadius = 20
        Me.btnBrowsePatient.CheckedState.Parent = Me.btnBrowsePatient
        Me.btnBrowsePatient.CustomImages.Parent = Me.btnBrowsePatient
        Me.btnBrowsePatient.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.btnBrowsePatient.ForeColor = System.Drawing.Color.White
        Me.btnBrowsePatient.HoverState.Parent = Me.btnBrowsePatient
        Me.btnBrowsePatient.Location = New System.Drawing.Point(298, 56)
        Me.btnBrowsePatient.Name = "btnBrowsePatient"
        Me.btnBrowsePatient.ShadowDecoration.Parent = Me.btnBrowsePatient
        Me.btnBrowsePatient.Size = New System.Drawing.Size(101, 38)
        Me.btnBrowsePatient.TabIndex = 30
        Me.btnBrowsePatient.Text = "Browse"
        '
        'btnBrowseItem
        '
        Me.btnBrowseItem.BorderRadius = 20
        Me.btnBrowseItem.CheckedState.Parent = Me.btnBrowseItem
        Me.btnBrowseItem.CustomImages.Parent = Me.btnBrowseItem
        Me.btnBrowseItem.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.btnBrowseItem.ForeColor = System.Drawing.Color.White
        Me.btnBrowseItem.HoverState.Parent = Me.btnBrowseItem
        Me.btnBrowseItem.Location = New System.Drawing.Point(298, 112)
        Me.btnBrowseItem.Name = "btnBrowseItem"
        Me.btnBrowseItem.ShadowDecoration.Parent = Me.btnBrowseItem
        Me.btnBrowseItem.Size = New System.Drawing.Size(101, 38)
        Me.btnBrowseItem.TabIndex = 29
        Me.btnBrowseItem.Text = "Browse"
        '
        'txtServiceID
        '
        Me.txtServiceID.BorderColor = System.Drawing.SystemColors.ControlDark
        Me.txtServiceID.BorderRadius = 10
        Me.txtServiceID.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtServiceID.DefaultText = ""
        Me.txtServiceID.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.txtServiceID.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.txtServiceID.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtServiceID.DisabledState.Parent = Me.txtServiceID
        Me.txtServiceID.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtServiceID.Enabled = False
        Me.txtServiceID.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtServiceID.FocusedState.Parent = Me.txtServiceID
        Me.txtServiceID.ForeColor = System.Drawing.Color.Black
        Me.txtServiceID.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtServiceID.HoverState.Parent = Me.txtServiceID
        Me.txtServiceID.Location = New System.Drawing.Point(16, 112)
        Me.txtServiceID.Name = "txtServiceID"
        Me.txtServiceID.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtServiceID.PlaceholderForeColor = System.Drawing.Color.Black
        Me.txtServiceID.PlaceholderText = "Service"
        Me.txtServiceID.SelectedText = ""
        Me.txtServiceID.ShadowDecoration.Parent = Me.txtServiceID
        Me.txtServiceID.Size = New System.Drawing.Size(276, 38)
        Me.txtServiceID.TabIndex = 28
        '
        'lblPatientName
        '
        Me.lblPatientName.AutoSize = True
        Me.lblPatientName.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPatientName.ForeColor = System.Drawing.Color.Black
        Me.lblPatientName.Location = New System.Drawing.Point(617, 93)
        Me.lblPatientName.Name = "lblPatientName"
        Me.lblPatientName.Size = New System.Drawing.Size(31, 21)
        Me.lblPatientName.TabIndex = 27
        Me.lblPatientName.Text = "[?]"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(481, 93)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(123, 21)
        Me.Label3.TabIndex = 26
        Me.Label3.Text = "Patient Name:"
        '
        'txtSubtotal
        '
        Me.txtSubtotal.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtSubtotal.DefaultText = ""
        Me.txtSubtotal.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.txtSubtotal.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.txtSubtotal.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtSubtotal.DisabledState.Parent = Me.txtSubtotal
        Me.txtSubtotal.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtSubtotal.Enabled = False
        Me.txtSubtotal.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtSubtotal.FocusedState.Parent = Me.txtSubtotal
        Me.txtSubtotal.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSubtotal.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtSubtotal.HoverState.Parent = Me.txtSubtotal
        Me.txtSubtotal.Location = New System.Drawing.Point(697, 528)
        Me.txtSubtotal.Margin = New System.Windows.Forms.Padding(5, 5, 5, 5)
        Me.txtSubtotal.Name = "txtSubtotal"
        Me.txtSubtotal.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtSubtotal.PlaceholderText = ""
        Me.txtSubtotal.SelectedText = ""
        Me.txtSubtotal.ShadowDecoration.Parent = Me.txtSubtotal
        Me.txtSubtotal.Size = New System.Drawing.Size(200, 36)
        Me.txtSubtotal.TabIndex = 48
        Me.txtSubtotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtPatientID
        '
        Me.txtPatientID.BorderColor = System.Drawing.SystemColors.ControlDark
        Me.txtPatientID.BorderRadius = 10
        Me.txtPatientID.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtPatientID.DefaultText = ""
        Me.txtPatientID.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.txtPatientID.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.txtPatientID.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtPatientID.DisabledState.Parent = Me.txtPatientID
        Me.txtPatientID.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtPatientID.Enabled = False
        Me.txtPatientID.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtPatientID.FocusedState.Parent = Me.txtPatientID
        Me.txtPatientID.ForeColor = System.Drawing.Color.Black
        Me.txtPatientID.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtPatientID.HoverState.Parent = Me.txtPatientID
        Me.txtPatientID.Location = New System.Drawing.Point(16, 56)
        Me.txtPatientID.Name = "txtPatientID"
        Me.txtPatientID.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtPatientID.PlaceholderForeColor = System.Drawing.Color.Black
        Me.txtPatientID.PlaceholderText = "Patient ID"
        Me.txtPatientID.SelectedText = ""
        Me.txtPatientID.ShadowDecoration.Parent = Me.txtPatientID
        Me.txtPatientID.Size = New System.Drawing.Size(276, 38)
        Me.txtPatientID.TabIndex = 25
        '
        'Guna2GroupBox1
        '
        Me.Guna2GroupBox1.Controls.Add(Me.txtAdditionalCharge)
        Me.Guna2GroupBox1.Controls.Add(Me.txtTransactionNo)
        Me.Guna2GroupBox1.Controls.Add(Me.Label4)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2Button4)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2Button3)
        Me.Guna2GroupBox1.Controls.Add(Me.Label9)
        Me.Guna2GroupBox1.Controls.Add(Me.lblServiceCost)
        Me.Guna2GroupBox1.Controls.Add(Me.Label1)
        Me.Guna2GroupBox1.Controls.Add(Me.lblIServiceName)
        Me.Guna2GroupBox1.Controls.Add(Me.Label2)
        Me.Guna2GroupBox1.Controls.Add(Me.btnBrowsePatient)
        Me.Guna2GroupBox1.Controls.Add(Me.btnBrowseItem)
        Me.Guna2GroupBox1.Controls.Add(Me.txtServiceID)
        Me.Guna2GroupBox1.Controls.Add(Me.lblPatientName)
        Me.Guna2GroupBox1.Controls.Add(Me.Label3)
        Me.Guna2GroupBox1.Controls.Add(Me.txtPatientID)
        Me.Guna2GroupBox1.CustomBorderColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(88, Byte), Integer))
        Me.Guna2GroupBox1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2GroupBox1.ForeColor = System.Drawing.Color.White
        Me.Guna2GroupBox1.Location = New System.Drawing.Point(12, 5)
        Me.Guna2GroupBox1.Name = "Guna2GroupBox1"
        Me.Guna2GroupBox1.ShadowDecoration.Parent = Me.Guna2GroupBox1
        Me.Guna2GroupBox1.Size = New System.Drawing.Size(885, 206)
        Me.Guna2GroupBox1.TabIndex = 44
        Me.Guna2GroupBox1.Text = "Add Transaction (Service)"
        '
        'txtAdditionalCharge
        '
        Me.txtAdditionalCharge.BorderColor = System.Drawing.SystemColors.ControlDark
        Me.txtAdditionalCharge.BorderRadius = 10
        Me.txtAdditionalCharge.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtAdditionalCharge.DefaultText = "0"
        Me.txtAdditionalCharge.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.txtAdditionalCharge.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.txtAdditionalCharge.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtAdditionalCharge.DisabledState.Parent = Me.txtAdditionalCharge
        Me.txtAdditionalCharge.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtAdditionalCharge.Enabled = False
        Me.txtAdditionalCharge.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtAdditionalCharge.FocusedState.Parent = Me.txtAdditionalCharge
        Me.txtAdditionalCharge.ForeColor = System.Drawing.Color.Black
        Me.txtAdditionalCharge.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtAdditionalCharge.HoverState.Parent = Me.txtAdditionalCharge
        Me.txtAdditionalCharge.Location = New System.Drawing.Point(612, 55)
        Me.txtAdditionalCharge.Name = "txtAdditionalCharge"
        Me.txtAdditionalCharge.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtAdditionalCharge.PlaceholderForeColor = System.Drawing.Color.Black
        Me.txtAdditionalCharge.PlaceholderText = ""
        Me.txtAdditionalCharge.SelectedText = ""
        Me.txtAdditionalCharge.SelectionStart = 1
        Me.txtAdditionalCharge.ShadowDecoration.Parent = Me.txtAdditionalCharge
        Me.txtAdditionalCharge.Size = New System.Drawing.Size(264, 39)
        Me.txtAdditionalCharge.TabIndex = 44
        Me.txtAdditionalCharge.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'UserControl_transaction_service
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.btnConfirmTransaction)
        Me.Controls.Add(Me.btnDeleteTransaction)
        Me.Controls.Add(Me.txtSubtotal)
        Me.Controls.Add(Me.Guna2GroupBox1)
        Me.Name = "UserControl_transaction_service"
        Me.Size = New System.Drawing.Size(909, 578)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.dgvServiceCart, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Guna2GroupBox1.ResumeLayout(False)
        Me.Guna2GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label5 As Label
    Friend WithEvents dgvServiceCart As Guna.UI2.WinForms.Guna2DataGridView
    Friend WithEvents action_delete As DataGridViewImageColumn
    Friend WithEvents txtTransactionNo As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Guna2Button4 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button3 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Label9 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents btnConfirmTransaction As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents lblServiceCost As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents lblIServiceName As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents btnDeleteTransaction As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents btnBrowsePatient As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents btnBrowseItem As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents txtServiceID As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents lblPatientName As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents txtSubtotal As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents txtPatientID As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2GroupBox1 As Guna.UI2.WinForms.Guna2GroupBox
    Friend WithEvents txtAdditionalCharge As Guna.UI2.WinForms.Guna2TextBox
End Class
