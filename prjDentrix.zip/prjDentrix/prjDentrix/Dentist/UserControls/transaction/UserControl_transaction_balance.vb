﻿Imports MySql.Data.MySqlClient

Public Class UserControl_transaction_balance
    Private Sub Guna2Button2_Click(sender As Object, e As EventArgs) Handles Guna2Button2.Click
        With frm_browse_patient
            .ShowDialog()
            txtPatientID.Text = .pid
            lblPatientName.Text = .pname
        End With
    End Sub

    Private Sub cmbTransactionType_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbTransactionType.SelectedValueChanged
        If cmbTransactionType.Text = "Service" Then
            displayBalanceService()
        Else
            displayBalanceItem()
        End If
    End Sub

    Private Sub displayBalanceService()
        conn.Open()
        Try
            comm = New MySqlCommand("prcDisplayBalanceServiceItem", conn)
            With comm
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@did", user_id)
                .Parameters.AddWithValue("@pid", txtPatientID.Text)
                .Parameters.AddWithValue("@stype", "Service")
                .ExecuteNonQuery()
            End With
            Dim da As New MySqlDataAdapter
            da.SelectCommand = comm
            Dim dt As New DataTable
            dt.Clear()
            da.Fill(dt)
            dgvBalance.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        conn.Close()
    End Sub

    Private Sub displayBalanceItem()
        conn.Open()
        Try
            comm = New MySqlCommand("prcDisplayBalanceServiceItem", conn)
            With comm
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@did", user_id)
                .Parameters.AddWithValue("@pid", txtPatientID.Text)
                .Parameters.AddWithValue("@stype", "Item")
                .ExecuteNonQuery()
            End With
            Dim da As New MySqlDataAdapter
            da.SelectCommand = comm
            Dim dt As New DataTable
            dt.Clear()
            da.Fill(dt)
            dgvBalance.DataSource = dt
        Catch ex As Exception
        End Try
        conn.Close()
    End Sub

    Private Sub txtPatientID_TextChanged(sender As Object, e As EventArgs) Handles txtPatientID.TextChanged
        If cmbTransactionType.Text = "Service" Then
            displayBalanceService()
        Else
            displayBalanceItem()
        End If
    End Sub

    Private Sub dgvBalance_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvBalance.CellClick
        Dim colName As String = dgvBalance.Columns(e.ColumnIndex).Name
        Dim selectedRow As DataGridViewRow
        Dim index As Integer
        Try
            index = e.RowIndex
            selectedRow = dgvBalance.Rows(index)

            With frm_confirm_payment_balance
                .tid = selectedRow.Cells(0).Value.ToString()
                .pid = selectedRow.Cells(1).Value.ToString()
                .bamt = selectedRow.Cells(3).Value.ToString()
                .amount_paid = selectedRow.Cells(4).Value.ToString()
                .stotal = selectedRow.Cells(5).Value.ToString()
                .transaction_type = cmbTransactionType.Text
                .ShowDialog()
            End With

            If cmbTransactionType.Text = "Service" Then
                displayBalanceService()
            Else
                displayBalanceItem()
            End If

        Catch ex As Exception
        End Try

    End Sub
End Class
