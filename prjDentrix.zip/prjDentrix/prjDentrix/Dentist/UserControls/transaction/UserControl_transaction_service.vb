﻿Imports MySql.Data.MySqlClient

Public Class UserControl_transaction_service
    Dim service_cost As Double
    Dim total_cost As Double
    Private Sub btnBrowseItem_Click(sender As Object, e As EventArgs) Handles btnBrowseItem.Click
        Try
            With frm_browse_service_type
                .ShowDialog()
                txtServiceID.Text = .sid
                lblIServiceName.Text = .sname
                lblServiceCost.Text = .scost
            End With
            service_cost = lblServiceCost.Text
        Catch ex As Exception

        End Try
    End Sub

    Private Sub btnBrowsePatient_Click(sender As Object, e As EventArgs) Handles btnBrowsePatient.Click
        With frm_browse_patient
            .ShowDialog()
            txtPatientID.Text = .pid
            lblPatientName.Text = .pname
        End With
    End Sub

    Private Sub txtAdditionalCharge_TextChanged(sender As Object, e As EventArgs)
        Try
            If txtAdditionalCharge.Text = "" Then
                total_cost = (service_cost) + 0
            Else
                total_cost = (service_cost + CDbl(txtAdditionalCharge.Text))
            End If
        Catch ex As Exception

        End Try
        lblServiceCost.Text = total_cost
    End Sub

    Private Sub txtServiceID_TextChanged(sender As Object, e As EventArgs) Handles txtServiceID.TextChanged
        If txtServiceID.Text = "" Then
            txtAdditionalCharge.Enabled = False
        Else
            txtAdditionalCharge.Enabled = True
            total_cost = 0
            lblServiceCost.Text = service_cost
            txtAdditionalCharge.Text = "0"
        End If
    End Sub

    Private Sub txtAdditionalCharge_TextChanged_1(sender As Object, e As EventArgs) Handles txtAdditionalCharge.TextChanged
        If IsNumeric(txtAdditionalCharge.Text) = False And txtAdditionalCharge.Text <> "" Then
            MsgBox("Please enter numeric value.")
            txtAdditionalCharge.Clear()
        End If

        Try
            If txtAdditionalCharge.Text = "" Then
                total_cost = (service_cost + 0)
            Else
                total_cost = service_cost + CDbl(txtAdditionalCharge.Text)
            End If
        Catch ex As Exception

        End Try
        lblServiceCost.Text = total_cost
    End Sub

    Private Sub Guna2Button3_Click(sender As Object, e As EventArgs) Handles Guna2Button3.Click
        If ValidateInputs() Then
            checkIfExist()
            displaySubtotal()
            ClearInputs()
        End If
        displayServiceTransaction()
    End Sub

    Private Function ValidateInputs() As Boolean
        If txtPatientID.Text = String.Empty Or txtServiceID.Text = String.Empty Or txtTransactionNo.Text = "[?]" Then
            MessageBox.Show("Please make sure to fill in the textboxes.")
            Return False
        Else
            If IsNumeric(txtAdditionalCharge.Text) = False Then
                MessageBox.Show("Additional Charge Must be numeric.")
                Return False
            End If
            Return True
        End If
    End Function

    Private Sub checkIfExist()
        conn.Open()
        Try
            comm = New MySqlCommand("prcCheckIfServiceExist", conn)
            With comm
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@tid", txtTransactionNo.Text)
                .Parameters.AddWithValue("@sid", txtServiceID.Text)
                .ExecuteNonQuery()
            End With
            Dim da As New MySqlDataAdapter
            da.SelectCommand = comm
            Dim dt As New DataTable
            dt.Clear()
            da.Fill(dt)
            If dt.Rows(0).Item(0).ToString() >= 1 Then
                MsgBox("Service already added.")
            Else
                InsertServiceTransaction()
            End If
        Catch ex As Exception
        End Try
        conn.Close()
    End Sub

    Private Sub InsertServiceTransaction()
        Try
            comm = New MySqlCommand("prcInsertPaymentService", conn)
            With comm
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@tid", txtTransactionNo.Text)
                .Parameters.AddWithValue("@sid", txtServiceID.Text)
                .Parameters.AddWithValue("@sname", lblIServiceName.Text)
                .Parameters.AddWithValue("@acharge", txtAdditionalCharge.Text)
                .Parameters.AddWithValue("@scost", lblServiceCost.Text)
                .Parameters.AddWithValue("@pdate", Format(Date.Now, "yyyy-MM-dd"))
                .ExecuteNonQuery()
            End With
        Catch ex As Exception
        End Try
    End Sub

    Private Sub displaySubtotal()
        Try
            conn.Open()
            comm = New MySqlCommand("prcCalculateSubTotalServices", conn)
            With comm
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@tid", txtTransactionNo.Text)
                .ExecuteNonQuery()
            End With
            adapter = New MySqlDataAdapter(comm)
            Dim table As New DataTable()
            adapter.Fill(table)

            If table.Rows.Count < 1 Then
                txtSubtotal.Text = ""
            Else
                txtSubtotal.Text = Format(CDbl(table.Rows(0).Item(0).ToString()), "₱###,###,###.##")
            End If

            conn.Close()
        Catch ex As Exception
            txtSubtotal.Text = ""
            conn.Close()
        Finally
            conn.Dispose()
        End Try
    End Sub

    Private Sub ClearInputs()
        Try
            txtServiceID.Text = String.Empty
            lblServiceCost.Text = "[?]"
            lblIServiceName.Text = "[?]"
            txtAdditionalCharge.Text = "0"
            service_cost = 0
            total_cost = 0
        Catch ex As Exception

        End Try
    End Sub

    Private Sub displayServiceTransaction()
        conn.Open()
        Try
            comm = New MySqlCommand("prcSelectPaymentService", conn)
            With comm
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@tid", txtTransactionNo.Text)
                .ExecuteNonQuery()
            End With
            Dim da As New MySqlDataAdapter
            da.SelectCommand = comm
            Dim dt As New DataTable
            dt.Clear()
            da.Fill(dt)
            dgvServiceCart.DataSource = dt
            If dt.Rows.Count > 0 Then
                btnBrowsePatient.Enabled = False
                btnConfirmTransaction.Visible = True
                btnDeleteTransaction.Visible = True
            Else
                btnBrowsePatient.Enabled = True
                btnConfirmTransaction.Visible = False
                btnDeleteTransaction.Visible = False
            End If
        Catch ex As Exception

        End Try
        conn.Close()
    End Sub

    Private Sub UserControl_transaction_service_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        getMaxCol()
        displayServiceTransaction()
        cancelAllTransaction()
        displayServiceTransaction()
    End Sub

    Private Sub getMaxCol()
        conn.Open()
        Try
            comm = New MySqlCommand("prcGetMaxColumnServiceTransaction", conn)
            With comm
                .CommandType = CommandType.StoredProcedure
                .ExecuteNonQuery()
            End With

            adapter = New MySqlDataAdapter(comm)
            Dim table As New DataTable()
            adapter.Fill(table)

            txtTransactionNo.Text = CInt(table.Rows(0).Item(0).ToString())

        Catch ex As Exception
            conn.Close()
        End Try
        conn.Close()
    End Sub

    Private Sub btnDeleteTransaction_Click(sender As Object, e As EventArgs) Handles btnDeleteTransaction.Click
        Dim dialogResult As DialogResult = MessageBox.Show("Do you want to cancel this transaction?", "Transaction", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If dialogResult = DialogResult.Yes Then
            cancelAllTransaction()
            displayServiceTransaction()
            txtSubtotal.Text = ""
        End If
    End Sub

    Private Sub cancelAllTransaction()
        conn.Open()
        Try
            comm = New MySqlCommand("prcDeleteTransactionService", conn)
            With comm
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@tid", txtTransactionNo.Text)
                .ExecuteNonQuery()
            End With
        Catch ex As Exception
        End Try
        conn.Close()
    End Sub

    Private Sub btnConfirmTransaction_Click(sender As Object, e As EventArgs) Handles btnConfirmTransaction.Click
        Try
            With frm_confirm_payment
                .subtotal = CDbl(txtSubtotal.Text)
                .patient_payer = txtPatientID.Text
                .transaction_no = txtTransactionNo.Text
                .transaction_type = "Service"
                .ShowDialog()
                getMaxCol()
                ClearInputs()
                displayServiceTransaction()

                If .isSubmitted Then
                    txtPatientID.Text = ""
                    lblPatientName.Text = "[?]"
                    txtSubtotal.Text = ""
                Else
                End If
            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Guna2Button4_Click(sender As Object, e As EventArgs) Handles Guna2Button4.Click
        ClearInputs()
        lblIServiceName.Text = "[?]"
        lblServiceCost.Text = "[?]"
    End Sub

    Private Sub dgvServiceCart_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvServiceCart.CellClick
        Dim colName As String = dgvServiceCart.Columns(e.ColumnIndex).Name
        Dim selectedRow As New DataGridViewRow
        Dim index As New Integer
        Try
            index = e.RowIndex
            selectedRow = dgvServiceCart.Rows(index)
            If colName = "action_delete" Then
                delete_service(selectedRow.Cells(1).Value.ToString, selectedRow.Cells(2).Value.ToString)
                displaySubtotal()
                displayServiceTransaction()
            End If
        Catch ex As Exception
        End Try
    End Sub

    Private Sub delete_service(ByVal tid As Integer, ByVal sid As Integer)
        Dim dialogResult As DialogResult = MessageBox.Show("Do you want to delete this record?", "Service", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If dialogResult = DialogResult.Yes Then
            conn.Open()
            Try
                comm = New MySqlCommand("prcDeleteServiceFromCart", conn)
                With comm
                    .CommandType = CommandType.StoredProcedure
                    .Parameters.AddWithValue("@tid", tid)
                    .Parameters.AddWithValue("@sid", sid)
                    .ExecuteNonQuery()
                End With
            Catch ex As Exception

            End Try
            conn.Close()
        End If
    End Sub
End Class
