﻿Imports MySql.Data.MySqlClient

Public Class frm_display_transaction_service
    Private Sub frm_display_transaction_service_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        getTotalServices()
        displayServiceTransaction()
        displayPaymentHistory()
    End Sub

    Private Sub displayServiceTransaction()
        conn.Open()
        Try
            comm = New MySqlCommand("prcSelectPaymentService", conn)
            With comm
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@tid", txtTransactionNo.Text)
                .ExecuteNonQuery()
            End With
            Dim da As New MySqlDataAdapter
            da.SelectCommand = comm
            Dim dt As New DataTable
            dt.Clear()
            da.Fill(dt)
            dgvTransactionService.DataSource = dt
        Catch ex As Exception
        End Try
        conn.Close()
    End Sub

    Private Sub displayPaymentHistory()
        conn.Open()
        Try
            comm = New MySqlCommand("prcDisplayBalanceHistoryService", conn)
            With comm
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@did", user_id)
                .Parameters.AddWithValue("@pid", txtPatientID.Text)
                .Parameters.AddWithValue("@tid", txtTransactionNo.Text)
                .ExecuteNonQuery()
            End With
            Dim da As New MySqlDataAdapter
            da.SelectCommand = comm
            Dim dt As New DataTable
            dt.Clear()
            da.Fill(dt)
            dgvPaymentHistory.DataSource = dt
        Catch ex As Exception
        End Try
        conn.Close()
    End Sub
    Private Sub getTotalServices()
        conn.Open()
        Try
            comm = New MySqlCommand("prcGetTotalServicesTransaction", conn)
            With comm
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@tid", txtTransactionNo.Text)
                .ExecuteNonQuery()
            End With
            Dim da As New MySqlDataAdapter
            da.SelectCommand = comm
            Dim dt As New DataTable
            dt.Clear()
            da.Fill(dt)

            txtTotalService.Text = dt.Rows(0).Item(0).ToString()
        Catch ex As Exception
        End Try
        conn.Close()
    End Sub

    Private Sub Guna2Button1_Click(sender As Object, e As EventArgs) Handles Guna2Button1.Click
        Panel1.Visible = True
        dgvTransactionService.Visible = True
        Panel2.Visible = False
        dgvPaymentHistory.Visible = False
    End Sub

    Private Sub Guna2Button3_Click(sender As Object, e As EventArgs) Handles Guna2Button3.Click
        Panel1.Visible = False
        dgvTransactionService.Visible = False
        Panel2.Visible = True
        dgvPaymentHistory.Visible = True
    End Sub

    Private Sub frm_display_transaction_service_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        Me.Dispose()
    End Sub
End Class