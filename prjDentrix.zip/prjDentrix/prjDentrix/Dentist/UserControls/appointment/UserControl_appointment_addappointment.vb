﻿Imports MySql.Data.MySqlClient

Public Class UserControl_appointment_addappointment
    Dim maxCol As Integer
    Private Sub UserControl_appointment_addappointment_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        getMaxCol()
        dtpAppointmentDate.Value = Date.Now
        dtpAppointmentDate.MinDate = Date.Now
    End Sub

    Private Sub getMaxCol()
        conn.Open()
        Try
            comm = New MySqlCommand("prcGetMaxColumnAppointment", conn)
            With comm
                .CommandType = CommandType.StoredProcedure
                .ExecuteNonQuery()
            End With

            adapter = New MySqlDataAdapter(comm)
            Dim table As New DataTable()
            adapter.Fill(table)
            maxCol = table.Rows(0).Item(0).ToString()
            lblAppointmentID.Text = maxCol

        Catch ex As Exception
            conn.Close()
        End Try
        conn.Close()
    End Sub
    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        Dim dialogResult As DialogResult = MessageBox.Show("Do you want to add this appointment?", "Appointment", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If dialogResult = DialogResult.Yes And ValidateInputs() Then
            conn.Open()
            Try
                comm = New MySqlCommand("prcAddAppointment", conn)
                With comm
                    .CommandType = CommandType.StoredProcedure
                    .Parameters.AddWithValue("@aaid", lblAppointmentID.Text)
                    .Parameters.AddWithValue("@aadesc", txtDescription.Text)
                    .Parameters.AddWithValue("@aadate", dtpAppointmentDate.Value.ToString("yyyy-MM-dd"))
                    .Parameters.AddWithValue("@aatime", txtTime.Text)
                    .ExecuteNonQuery()
                End With
            Catch ex As Exception
                conn.Close()
            End Try

            Try
                comm = New MySqlCommand("prcPatientAppointmentRelationship", conn)
                With comm
                    .CommandType = CommandType.StoredProcedure
                    .Parameters.AddWithValue("@did", user_id)
                    .Parameters.AddWithValue("@pid", txtPatientID.Text)
                    .Parameters.AddWithValue("@aid", lblAppointmentID.Text)
                    .ExecuteNonQuery()
                End With
            Catch ex As Exception
                conn.Close()
            End Try
            conn.Close()
            insertToLogs(user_id, "appointment", "insert", u_employee, "User added appointment id: " & lblAppointmentID.Text)
            ClearInputs()
            getMaxCol()
        End If
    End Sub
    Private Sub ClearInputs()
        txtDescription.Text = String.Empty
        txtTime.Text = String.Empty
        txtPatientID.Text = String.Empty
        txtServiceID.Text = String.Empty
        lblPatientName.Text = "[?]"
        dtpAppointmentDate.Value = Date.Now
    End Sub

    Private Function ValidateInputs() As Boolean
        If txtTime.Text = String.Empty Or txtDescription.Text = String.Empty Or txtPatientID.Text = String.Empty Or txtServiceID.Text = String.Empty Or cmbTime.Text = String.Empty Then
            MessageBox.Show("Please fill in the textbox.")
            Return False
        Else
            Return True
        End If
    End Function
    Private Sub Guna2Button2_Click(sender As Object, e As EventArgs) Handles Guna2Button2.Click
        With frm_browse_patient
            .ShowDialog()
            txtPatientID.Text = .pid
            lblPatientName.Text = .pname
        End With
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        ClearInputs()
    End Sub

    Private Sub txtPatientID_TextChanged(sender As Object, e As EventArgs) Handles txtPatientID.TextChanged
        If txtPatientID.Text = "" Then
            txtDescription.Enabled = False
            txtTime.Enabled = False
            dtpAppointmentDate.Enabled = False
            cmbTime.Enabled = False
        Else
            txtDescription.Enabled = True
            txtTime.Enabled = True
            dtpAppointmentDate.Enabled = True
            cmbTime.Enabled = True
        End If

    End Sub

    Private Sub Guna2Button1_Click(sender As Object, e As EventArgs) Handles Guna2Button1.Click
        With frm_browse_service_type
            .ShowDialog()
            txtServiceID.Text = .sid
            lblServiceName.Text = .sname
            txtDescription.Text = "Appointment for " & .sname
        End With
    End Sub

    Private Sub cmbTime_SelectedValueChanged(sender As Object, e As EventArgs) Handles cmbTime.SelectedValueChanged
        If cmbTime.Text = "7:00 AM" Then
            txtTime.Text = "7:00"
        ElseIf cmbTime.Text = "7:30 AM" Then
            txtTime.Text = "7:30"
        ElseIf cmbTime.Text = "8:00 AM" Then
            txtTime.Text = "8:00"
        ElseIf cmbTime.Text = "8:30 AM" Then
            txtTime.Text = "8:30"
        ElseIf cmbTime.Text = "9:00 AM" Then
            txtTime.Text = "9:00"
        ElseIf cmbTime.Text = "9:30 AM" Then
            txtTime.Text = "9:30"
        ElseIf cmbTime.Text = "10:00 AM" Then
            txtTime.Text = "10:00"
        ElseIf cmbTime.Text = "10:30 AM" Then
            txtTime.Text = "10:30"
        ElseIf cmbTime.Text = "11:00 AM" Then
            txtTime.Text = "11:00"
        ElseIf cmbTime.Text = "11:30 AM" Then
            txtTime.Text = "11:30"
        ElseIf cmbTime.Text = "12:00 PM" Then
            txtTime.Text = "12:00"
        ElseIf cmbTime.Text = "12:30 PM" Then
            txtTime.Text = "12:30"
        ElseIf cmbTime.Text = "1:00 PM" Then
            txtTime.Text = "13:00"
        ElseIf cmbTime.Text = "13:30 PM" Then
            txtTime.Text = "13:00"
        ElseIf cmbTime.Text = "2:00 PM" Then
            txtTime.Text = "14:00"
        ElseIf cmbTime.Text = "2:30 PM" Then
            txtTime.Text = "14:30"
        ElseIf cmbTime.Text = "3:00 PM" Then
            txtTime.Text = "15:00"
        ElseIf cmbTime.Text = "3:30 PM" Then
            txtTime.Text = "15:30"
        ElseIf cmbTime.Text = "4:00 PM" Then
            txtTime.Text = "16:00"
        ElseIf cmbTime.Text = "4:30 PM" Then
            txtTime.Text = "16:30"
        ElseIf cmbTime.Text = "5:00 PM" Then
            txtTime.Text = "17:00"
        ElseIf cmbTime.Text = "5:30 PM" Then
            txtTime.Text = "17:30"
        End If
    End Sub
End Class
