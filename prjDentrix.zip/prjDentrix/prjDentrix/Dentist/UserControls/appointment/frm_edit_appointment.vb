﻿Imports MySql.Data.MySqlClient

Public Class frm_edit_appointment
    Dim isDone As String
    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        Dim dialogResult As DialogResult = MessageBox.Show("Do you want to edit this appointment?", "Appointment", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If dialogResult = DialogResult.Yes And ValidateInputs() Then
            conn.Open()
            Try
                comm = New MySqlCommand("prcUpdateAppointment", conn)
                With comm
                    .CommandType = CommandType.StoredProcedure
                    .Parameters.AddWithValue("@aid", lblAppointmentID.Text)
                    .Parameters.AddWithValue("@adesc", txtDescription.Text)
                    .Parameters.AddWithValue("@adate", dtpAppointmentDate.Value.ToString("yyyy-MM-dd"))
                    .Parameters.AddWithValue("@atime", txtTime.Text)
                    .Parameters.AddWithValue("@astatus", cmbStatus.Text)
                    .ExecuteNonQuery()
                End With
            Catch ex As Exception
                conn.Close()
            End Try
            conn.Close()
        End If
        insertToLogs(user_id, "appointment", "edit", u_employee, "User edit appointment id: " & lblAppointmentID.Text)
        Me.Dispose()
    End Sub

    Private Function ValidateInputs() As Boolean
        If txtTime.Text = String.Empty Or txtDescription.Text = String.Empty Then
            MessageBox.Show("Please fill in the textbox.")
            Return False
        Else
            Return True
        End If
    End Function

    Private Sub frm_edit_appointment_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If txtTime.Text = "07:00" Then
            cmbTime.SelectedIndex = 0
        ElseIf txtTime.Text = "07:30" Then
            cmbTime.SelectedIndex = 1
        ElseIf txtTime.Text = "08:00" Then
            cmbTime.SelectedIndex = 2
        ElseIf txtTime.Text = "08:30" Then
            cmbTime.SelectedIndex = 3
        ElseIf txtTime.Text = "09:00" Then
            cmbTime.SelectedIndex = 4
        ElseIf txtTime.Text = "09:30" Then
            cmbTime.SelectedIndex = 5
        ElseIf txtTime.Text = "10:00" Then
            cmbTime.SelectedIndex = 6
        ElseIf txtTime.Text = "10:30" Then
            cmbTime.SelectedIndex = 7
        ElseIf txtTime.Text = "11:00" Then
            cmbTime.SelectedIndex = 8
        ElseIf txtTime.Text = "11:30" Then
            cmbTime.SelectedIndex = 9
        ElseIf txtTime.Text = "12:00" Then
            cmbTime.SelectedIndex = 10
        ElseIf txtTime.Text = "12:30" Then
            cmbTime.SelectedIndex = 11
        ElseIf txtTime.Text = "13:00" Then
            cmbTime.SelectedIndex = 12
        ElseIf txtTime.Text = "13:30" Then
            cmbTime.SelectedIndex = 13
        ElseIf txtTime.Text = "14:00" Then
            cmbTime.SelectedIndex = 14
        ElseIf txtTime.Text = "14:30" Then
            cmbTime.SelectedIndex = 15
        ElseIf txtTime.Text = "15:00" Then
            cmbTime.SelectedIndex = 16
        ElseIf txtTime.Text = "15:30" Then
            cmbTime.SelectedIndex = 17
        ElseIf txtTime.Text = "16:00" Then
            cmbTime.SelectedIndex = 18
        ElseIf txtTime.Text = "16:30" Then
            cmbTime.SelectedIndex = 19
        ElseIf txtTime.Text = "17:00" Then
            cmbTime.SelectedIndex = 20
        ElseIf txtTime.Text = "17:30" Then
            cmbTime.SelectedIndex = 21
        End If
    End Sub

    Private Sub cmbTime_SelectedValueChanged(sender As Object, e As EventArgs) Handles cmbTime.SelectedValueChanged
        If cmbTime.Text = "7:00 AM" Then
            txtTime.Text = "7:00"
        ElseIf cmbTime.Text = "7:30 AM" Then
            txtTime.Text = "7:30"
        ElseIf cmbTime.Text = "8:00 AM" Then
            txtTime.Text = "8:00"
        ElseIf cmbTime.Text = "8:30 AM" Then
            txtTime.Text = "8:30"
        ElseIf cmbTime.Text = "9:00 AM" Then
            txtTime.Text = "9:00"
        ElseIf cmbTime.Text = "9:30 AM" Then
            txtTime.Text = "9:30"
        ElseIf cmbTime.Text = "10:00 AM" Then
            txtTime.Text = "10:00"
        ElseIf cmbTime.Text = "10:30 AM" Then
            txtTime.Text = "10:30"
        ElseIf cmbTime.Text = "11:00 AM" Then
            txtTime.Text = "11:00"
        ElseIf cmbTime.Text = "11:30 AM" Then
            txtTime.Text = "11:30"
        ElseIf cmbTime.Text = "12:00 PM" Then
            txtTime.Text = "12:00"
        ElseIf cmbTime.Text = "12:30 PM" Then
            txtTime.Text = "12:30"
        ElseIf cmbTime.Text = "1:00 PM" Then
            txtTime.Text = "13:00"
        ElseIf cmbTime.Text = "1:30 PM" Then
            txtTime.Text = "13:30"
        ElseIf cmbTime.Text = "2:00 PM" Then
            txtTime.Text = "14:00"
        ElseIf cmbTime.Text = "2:30 PM" Then
            txtTime.Text = "14:30"
        ElseIf cmbTime.Text = "3:00 PM" Then
            txtTime.Text = "15:00"
        ElseIf cmbTime.Text = "3:30 PM" Then
            txtTime.Text = "15:30"
        ElseIf cmbTime.Text = "4:00 PM" Then
            txtTime.Text = "16:00"
        ElseIf cmbTime.Text = "4:30 PM" Then
            txtTime.Text = "16:30"
        ElseIf cmbTime.Text = "5:00 PM" Then
            txtTime.Text = "17:00"
        ElseIf cmbTime.Text = "5:30 PM" Then
            txtTime.Text = "17:30"
        End If
    End Sub

    Private Sub frm_edit_appointment_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        Me.Dispose()
    End Sub

End Class