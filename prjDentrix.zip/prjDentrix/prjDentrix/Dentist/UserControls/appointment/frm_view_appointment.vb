﻿Public Class frm_view_appointment
    Private Sub frm_view_appointment_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If txtTime.Text = "07:00" Then
            cmbTime.SelectedIndex = 0
        ElseIf txtTime.Text = "07:30" Then
            cmbTime.SelectedIndex = 1
        ElseIf txtTime.Text = "08:00" Then
            cmbTime.SelectedIndex = 2
        ElseIf txtTime.Text = "08:30" Then
            cmbTime.SelectedIndex = 3
        ElseIf txtTime.Text = "09:00" Then
            cmbTime.SelectedIndex = 4
        ElseIf txtTime.Text = "09:30" Then
            cmbTime.SelectedIndex = 5
        ElseIf txtTime.Text = "10:00" Then
            cmbTime.SelectedIndex = 6
        ElseIf txtTime.Text = "10:30" Then
            cmbTime.SelectedIndex = 7
        ElseIf txtTime.Text = "11:00" Then
            cmbTime.SelectedIndex = 8
        ElseIf txtTime.Text = "11:30" Then
            cmbTime.SelectedIndex = 9
        ElseIf txtTime.Text = "12:00" Then
            cmbTime.SelectedIndex = 10
        ElseIf txtTime.Text = "12:30" Then
            cmbTime.SelectedIndex = 11
        ElseIf txtTime.Text = "13:00" Then
            cmbTime.SelectedIndex = 12
        ElseIf txtTime.Text = "13:30" Then
            cmbTime.SelectedIndex = 13
        ElseIf txtTime.Text = "14:00" Then
            cmbTime.SelectedIndex = 14
        ElseIf txtTime.Text = "14:30" Then
            cmbTime.SelectedIndex = 15
        ElseIf txtTime.Text = "15:00" Then
            cmbTime.SelectedIndex = 16
        ElseIf txtTime.Text = "15:30" Then
            cmbTime.SelectedIndex = 17
        ElseIf txtTime.Text = "16:00" Then
            cmbTime.SelectedIndex = 18
        ElseIf txtTime.Text = "16:30" Then
            cmbTime.SelectedIndex = 19
        ElseIf txtTime.Text = "17:00" Then
            cmbTime.SelectedIndex = 20
        ElseIf txtTime.Text = "17:30" Then
            cmbTime.SelectedIndex = 21
        End If
    End Sub

    Private Sub frm_view_appointment_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        Me.Dispose()
    End Sub
End Class