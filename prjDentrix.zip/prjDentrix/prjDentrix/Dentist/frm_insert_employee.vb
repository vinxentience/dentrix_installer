﻿Imports MySql.Data.MySqlClient

Public Class frm_insert_employee
    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        Dim dialogResult As DialogResult = MessageBox.Show("Do you want to add this employee?", "Employee", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If dialogResult = DialogResult.Yes And ValidateInputs() Then
            Try
                conn.Open()
                comm = New MySqlCommand("prcAddEmployee", conn)
                With comm
                    .CommandType = CommandType.StoredProcedure
                    .Parameters.AddWithValue("@did", user_id)
                    .Parameters.AddWithValue("@eid", txtEmployeeID.Text)
                    .Parameters.AddWithValue("@ename", txtFname.Text & " " & txtLname.Text)
                    .ExecuteNonQuery()
                End With
                Me.Close()
                conn.Close()
            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                conn.Dispose()
            End Try
        End If
    End Sub

    Private Function ValidateInputs() As Boolean
        If txtFname.Text = String.Empty Or txtLname.Text = String.Empty Then
            MessageBox.Show("Please fill in the textbox.")
            Return False
        Else
            Return True
        End If
    End Function

    Private Sub frm_insert_employee_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            conn.Open()
            comm = New MySqlCommand("prcGetMaxColumnEmployee", conn)
            With comm
                .CommandType = CommandType.StoredProcedure
                .ExecuteNonQuery()
            End With
            adapter = New MySqlDataAdapter(comm)
            Dim table As New DataTable()
            adapter.Fill(table)

            txtEmployeeID.Text = table.Rows(0).Item(0).ToString()

            conn.Close()
        Catch ex As Exception
            conn.Close()
        Finally
            conn.Dispose()
        End Try
    End Sub
End Class